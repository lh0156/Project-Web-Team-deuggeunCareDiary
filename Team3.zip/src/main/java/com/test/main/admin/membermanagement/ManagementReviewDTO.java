package com.test.main.admin.membermanagement;

public class ManagementReviewDTO {
	String reviewseq;
	String productseq;
	String productname;
	String reviewcontent;
	String reviewpoint;
	String reviewdate;
	
	
	public String getReviewseq() {
		return reviewseq;
	}
	public void setReviewseq(String reviewseq) {
		this.reviewseq = reviewseq;
	}
	public String getProductseq() {
		return productseq;
	}
	public void setProductseq(String productseq) {
		this.productseq = productseq;
	}
	public String getProductname() {
		return productname;
	}
	public void setProductname(String productname) {
		this.productname = productname;
	}
	public String getReviewcontent() {
		return reviewcontent;
	}
	public void setReviewcontent(String reviewcontent) {
		this.reviewcontent = reviewcontent;
	}
	public String getReviewpoint() {
		return reviewpoint;
	}
	public void setReviewpoint(String reviewpoint) {
		this.reviewpoint = reviewpoint;
	}
	public String getReviewdate() {
		return reviewdate;
	}
	public void setReviewdate(String reviewdate) {
		this.reviewdate = reviewdate;
	}
	
	
}
