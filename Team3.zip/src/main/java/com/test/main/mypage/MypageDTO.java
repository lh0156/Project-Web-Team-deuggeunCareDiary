package com.test.main.mypage;

public class MypageDTO {
	
	private String productname;
	private String orderdate;
	private String reviewcontent;
	private String reviewdate;
	
	private String QACategory;
	private String QAAnswer;
	private String QAContent;
	private String QADate;
	private String process;
	private String postdate;
	private String stock;
	private String imgurl;
	private String courier;
	private String invoicenum;
	private String eachorderseq;
	private String totalprice;
	
	
	
	private String pay;
	private String usemileage;
	
	private String orderaddress;
	private String redate;
	
	
	
	
	
	
	
	
	
	public String getOrderaddress() {
		return orderaddress;
	}
	public void setOrderaddress(String orderaddress) {
		this.orderaddress = orderaddress;
	}
	public String getRedate() {
		return redate;
	}
	public void setRedate(String redate) {
		this.redate = redate;
	}
	public String getPay() {
		return pay;
	}
	public void setPay(String pay) {
		this.pay = pay;
	}
	public String getUsemileage() {
		return usemileage;
	}
	public void setUsemileage(String usemileage) {
		this.usemileage = usemileage;
	}
	public String getEachorderseq() {
		return eachorderseq;
	}
	public void setEachorderseq(String eachorderseq) {
		this.eachorderseq = eachorderseq;
	}
	
	
	public String getCourier() {
		return courier;
	}
	public void setCourier(String courier) {
		this.courier = courier;
	}
	public String getInvoicenum() {
		return invoicenum;
	}
	public void setInvoicenum(String invoicenum) {
		this.invoicenum = invoicenum;
	}
	public String getProcess() {
		return process;
	}
	public void setProcess(String process) {
		this.process = process;
	}
	public String getPostdate() {
		return postdate;
	}
	public void setPostdate(String postdate) {
		this.postdate = postdate;
	}
	public String getStock() {
		return stock;
	}
	public void setStock(String stock) {
		this.stock = stock;
	}
	public String getTotalprice() {
		return totalprice;
	}
	public void setTotalprice(String totalprice) {
		this.totalprice = totalprice;
	}
	public String getImgurl() {
		return imgurl;
	}
	public void setImgurl(String imgurl) {
		this.imgurl = imgurl;
	}
	public String getQACategory() {
		return QACategory;
	}
	public void setQACategory(String qACategory) {
		QACategory = qACategory;
	}
	public String getQAAnswer() {
		return QAAnswer;
	}
	public void setQAAnswer(String qAAnswer) {
		QAAnswer = qAAnswer;
	}
	public String getQAContent() {
		return QAContent;
	}
	public void setQAContent(String qAContent) {
		QAContent = qAContent;
	}
	public String getQADate() {
		return QADate;
	}
	public void setQADate(String qADate) {
		QADate = qADate;
	}
	public String getProductname() {
		return productname;
	}
	public void setProductname(String productname) {
		this.productname = productname;
	}
	public String getOrderdate() {
		return orderdate;
	}
	public void setOrderdate(String orderdate) {
		this.orderdate = orderdate;
	}
	public String getReviewcontent() {
		return reviewcontent;
	}
	public void setReviewcontent(String reviewcontent) {
		this.reviewcontent = reviewcontent;
	}
	public String getReviewdate() {
		return reviewdate;
	}
	public void setReviewdate(String reviewdate) {
		this.reviewdate = reviewdate;
	}
	
	
	
}
