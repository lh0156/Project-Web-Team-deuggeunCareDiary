create sequence order_seq;
create sequence eachOrder_seq;
create sequence review_seq;
create sequence refund_seq;
create sequence wantSpec_seq;
create sequence basket_seq;
create sequence Video_seq;
CREATE SEQUENCE member_Seq;
CREATE SEQUENCE weight_Seq;
CREATE SEQUENCE fat_Seq;
CREATE SEQUENCE muscle_Seq;
create sequence CSVoice_seq;
create sequence QA_Seq;
create sequence QADelivery_Seq;
create sequence QAProduct_Seq;
Create sequence product_seq;
Create sequence productUrl_seq;
Create sequence OtherNT_seq;
Create sequence EN_seq;




drop sequence order_seq;
drop sequence eachOrder_seq;
drop sequence review_seq;
drop sequence refund_seq;
drop sequence wantSpec_seq;
drop SEQUENCE muscle_Seq;
drop sequence basket_seq;
drop sequence Video_seq;
drop SEQUENCE member_Seq;
drop SEQUENCE weight_Seq;
drop SEQUENCE fat_Seq;
drop sequence CSVoice_seq;
drop sequence QA_Seq;
drop sequence QADelivery_Seq;
drop sequence QAProduct_Seq;
drop sequence product_seq;
drop sequence productUrl_seq;
drop sequence OtherNT_seq;
drop sequence EN_seq;
