-- Table
drop table tblOrder CASCADE CONSTRAINTS;
drop table tblEachOrder CASCADE CONSTRAINTS;
drop table tblReview CASCADE CONSTRAINTS;
drop table tblRefund CASCADE CONSTRAINTS;
drop table tblWantSpec CASCADE CONSTRAINTS;
drop table tblBasket CASCADE CONSTRAINTS;
drop table tblVideo CASCADE CONSTRAINTS;
drop table tblMember CASCADE CONSTRAINTS;
drop table tblWeight CASCADE CONSTRAINTS;
drop table tblFat CASCADE CONSTRAINTS;
drop table tblMuscle CASCADE CONSTRAINTS;
drop table tblProduct CASCADE CONSTRAINTS;
drop table tblProductURL CASCADE CONSTRAINTS;
drop table tblEssentialNT CASCADE CONSTRAINTS;
drop table tblOtherNT CASCADE CONSTRAINTS;
drop table tblCSVoice CASCADE CONSTRAINTS;
drop table tblQA CASCADE CONSTRAINTS;
drop table tblQADelivery CASCADE CONSTRAINTS;
drop table tblQAProduct CASCADE CONSTRAINTS;


