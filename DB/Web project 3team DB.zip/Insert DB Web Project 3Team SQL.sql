-- 회원 정보 Member(O)
Insert into tblMember (memberSeq,NAME,ID,PASSWORD,JUMIN,GENDER,POSTALCODE,ADDRESS,TEL,EMAIL,GRADE,ACCOUNTSTATUS,MILEAGE) values ('MB'||Member_Seq.nextVal,'한경수','admin','1111','730217','여자','31131','충청남도 천안시 동남구 큰시장길 37  1002호(영성동  파고다주상복합아파트)','010-4690-6012','YCC9vlbG@naver.com','관리자','일반',0);
Insert into tblMember (memberSeq,NAME,ID,PASSWORD,JUMIN,GENDER,POSTALCODE,ADDRESS,TEL,EMAIL,GRADE,ACCOUNTSTATUS,MILEAGE) values ('MB'||Member_Seq.nextVal,'정준기','aaf1698','W6THSHlx','990514','남자','17866','경기도 평택시 신흥마을2길 28-4  402호(용이동  해돋이마을)','010-1593-1838','DDxw2NWd@hanmail.net','회원','일반',5451);
Insert into tblMember (memberSeq,NAME,ID,PASSWORD,JUMIN,GENDER,POSTALCODE,ADDRESS,TEL,EMAIL,GRADE,ACCOUNTSTATUS,MILEAGE) values ('MB'||Member_Seq.nextVal,'최빈기','aau5323','HpSfea','931114','남자','49089','부산광역시 영도구 상리로 1  402동 1411호(동삼동  주공아파트  동삼그린힐아파트)','010-7179-7990','X9Nlz7hg@gmail.com','회원','일반',2896);
Insert into tblMember (memberSeq,NAME,ID,PASSWORD,JUMIN,GENDER,POSTALCODE,ADDRESS,TEL,EMAIL,GRADE,ACCOUNTSTATUS,MILEAGE) values ('MB'||Member_Seq.nextVal,'한장연','aaw1003','g20xFHQjmXLA','940518','여자','10306','경기도 고양시 일산동구 숲속마을로 70  지하 1층 B105호(풍동)','010-9510-4521','Tmvs2ww3@naver.com','회원','일반',64);
Insert into tblMember (memberSeq,NAME,ID,PASSWORD,JUMIN,GENDER,POSTALCODE,ADDRESS,TEL,EMAIL,GRADE,ACCOUNTSTATUS,MILEAGE) values ('MB'||Member_Seq.nextVal,'심혁연','abb8113','ZxZtVTy','871116','여자','41193','대구광역시 동구 아양로15길 90-8  401호(신암동  경북빌라)','010-0295-6395','7ikrCdoy@gmail.com','회원','일반',685);
Insert into tblMember (memberSeq,NAME,ID,PASSWORD,JUMIN,GENDER,POSTALCODE,ADDRESS,TEL,EMAIL,GRADE,ACCOUNTSTATUS,MILEAGE) values ('MB'||Member_Seq.nextVal,'심선수','abu1560','3iF20D7AzE','941218','남자','38149','경상북도 경주시 양정로 142  208호(성동동  신운빌라)','010-9115-8514','KoNOiLOQ@naver.com','회원','정지',967);
Insert into tblMember (memberSeq,NAME,ID,PASSWORD,JUMIN,GENDER,POSTALCODE,ADDRESS,TEL,EMAIL,GRADE,ACCOUNTSTATUS,MILEAGE) values ('MB'||Member_Seq.nextVal,'장준경','acx5888','q2LnHxqhwGk','940524','남자','57939','전라남도 순천시 강변로 833  201호(동외동  빌라)','010-6818-7472','tAcjxHsd@hanmail.net','회원','일반',7514);
Insert into tblMember (memberSeq,NAME,ID,PASSWORD,JUMIN,GENDER,POSTALCODE,ADDRESS,TEL,EMAIL,GRADE,ACCOUNTSTATUS,MILEAGE) values ('MB'||Member_Seq.nextVal,'심연정','acy5458','3aonheLRaRB','730102','여자','1780','서울특별시 노원구 섬밭로 232  105동 1408호(하계동  현대아파트 우성아파트)','010-5629-8749','Oy0cPQyw@gmail.com','회원','정지',10119);
Insert into tblMember (memberSeq,NAME,ID,PASSWORD,JUMIN,GENDER,POSTALCODE,ADDRESS,TEL,EMAIL,GRADE,ACCOUNTSTATUS,MILEAGE) values ('MB'||Member_Seq.nextVal,'최혜정','aee6351','2IA9iUk','720124','남자','33646','충청남도 서천군 서천읍 충절로81번길 7  210호','010-2420-9638','G14bVS97@yahoo.com','회원','일반',1099);
Insert into tblMember (memberSeq,NAME,ID,PASSWORD,JUMIN,GENDER,POSTALCODE,ADDRESS,TEL,EMAIL,GRADE,ACCOUNTSTATUS,MILEAGE) values ('MB'||Member_Seq.nextVal,'정현빈','aeq3162','8AYgLr','730722','여자','38592','경상북도 경산시 계양로8길 23  201호(계양동  금강도운빌라계양1차)','010-1401-1711','ciTq6p8S@gmail.com','회원','일반',97);
Insert into tblMember (memberSeq,NAME,ID,PASSWORD,JUMIN,GENDER,POSTALCODE,ADDRESS,TEL,EMAIL,GRADE,ACCOUNTSTATUS,MILEAGE) values ('MB'||Member_Seq.nextVal,'정하연','afc7784','SrVU6GkG','920319','남자','7336','서울특별시 영등포구 여의나루로 121  2동 305호(여의도동  서울아파트)','010-4592-6426','4ncxWALG@hanmail.net','회원','일반',3210);
Insert into tblMember (memberSeq,NAME,ID,PASSWORD,JUMIN,GENDER,POSTALCODE,ADDRESS,TEL,EMAIL,GRADE,ACCOUNTSTATUS,MILEAGE) values ('MB'||Member_Seq.nextVal,'주규연','afx4571','yZDr5ch','720320','남자','38582','경상북도 경산시 계양로16길 92  301호(사동  도운사동빌라1차)','010-2207-4779','r7dCwIqC@hanmail.net','회원','일반',9006);
Insert into tblMember (memberSeq,NAME,ID,PASSWORD,JUMIN,GENDER,POSTALCODE,ADDRESS,TEL,EMAIL,GRADE,ACCOUNTSTATUS,MILEAGE) values ('MB'||Member_Seq.nextVal,'송장빈','age6579','BCjFCn4','710914','여자','63584','제주특별자치도 서귀포시 솜반천로 47  지하 101호(서홍동  보성아파트)','010-0686-4066','OvqZL3G1@yahoo.com','회원','일반',11);
Insert into tblMember (memberSeq,NAME,ID,PASSWORD,JUMIN,GENDER,POSTALCODE,ADDRESS,TEL,EMAIL,GRADE,ACCOUNTSTATUS,MILEAGE) values ('MB'||Member_Seq.nextVal,'김한준','agf8430','IzGvAH','750220','여자','38689','경상북도 경산시 선비길 7-7  1동 101호(옥곡동  참아름빌라)','010-8332-9654','malsZQ7Y@yahoo.com','회원','일반',70);
Insert into tblMember (memberSeq,NAME,ID,PASSWORD,JUMIN,GENDER,POSTALCODE,ADDRESS,TEL,EMAIL,GRADE,ACCOUNTSTATUS,MILEAGE) values ('MB'||Member_Seq.nextVal,'장기희','agu7010','NogSxuq','870601','여자','53219','경상남도 거제시 국산1길 23  202호(옥포동  참누리빌라)','010-2953-6770','8UxWmiog@naver.com','회원','일반',119);
Insert into tblMember (memberSeq,NAME,ID,PASSWORD,JUMIN,GENDER,POSTALCODE,ADDRESS,TEL,EMAIL,GRADE,ACCOUNTSTATUS,MILEAGE) values ('MB'||Member_Seq.nextVal,'임신한','agv9862','lKUkLoL0kQrf','720625','여자','11956','경기도 구리시 아치울길 9  302호(아천동  빌라드그리움W)','010-1089-4401','8PiFyBoh@naver.com','회원','일반',4933);
Insert into tblMember (memberSeq,NAME,ID,PASSWORD,JUMIN,GENDER,POSTALCODE,ADDRESS,TEL,EMAIL,GRADE,ACCOUNTSTATUS,MILEAGE) values ('MB'||Member_Seq.nextVal,'윤빈하','aih9799','jGLlBmTi','820623','여자','6520','서울특별시 서초구 잠원로 86  338동 811호(잠원동  신반포아파트 신반포22차아파트)','010-8039-9806','lQ0qwTVD@gmail.com','회원','일반',59098);
Insert into tblMember (memberSeq,NAME,ID,PASSWORD,JUMIN,GENDER,POSTALCODE,ADDRESS,TEL,EMAIL,GRADE,ACCOUNTSTATUS,MILEAGE) values ('MB'||Member_Seq.nextVal,'한기연','ais9725','dSDijlMZso','880613','여자','15859','경기도 군포시 금당로 78  B동 201호(당동  유한빌라)','010-4953-0236','npwbYhJR@hanmail.net','회원','정지',1449);
Insert into tblMember (memberSeq,NAME,ID,PASSWORD,JUMIN,GENDER,POSTALCODE,ADDRESS,TEL,EMAIL,GRADE,ACCOUNTSTATUS,MILEAGE) values ('MB'||Member_Seq.nextVal,'심기빈','aji6185','jubv7J9','741005','여자','22683','인천광역시 서구 고산후로78번길 9  304동 801호(당하동  인천원당금호어울림아파트)','010-2202-2604','YkDbAusI@gmail.com','회원','일반',14195);
Insert into tblMember (memberSeq,NAME,ID,PASSWORD,JUMIN,GENDER,POSTALCODE,ADDRESS,TEL,EMAIL,GRADE,ACCOUNTSTATUS,MILEAGE) values ('MB'||Member_Seq.nextVal,'심신혁','ajw1013','YuPaz6rh','821218','여자','57805','전라남도 광양시 금호로 244  16동 305호(금호동  목련빌라)','010-5276-8330','YDnOAc5t@naver.com','회원','일반',9437);
Insert into tblMember (memberSeq,NAME,ID,PASSWORD,JUMIN,GENDER,POSTALCODE,ADDRESS,TEL,EMAIL,GRADE,ACCOUNTSTATUS,MILEAGE) values ('MB'||Member_Seq.nextVal,'김하혁','akb7136','aGKfK4q4','770805','여자','22325','인천광역시 중구 인중로 111  102동 2203호(신생동  삼성아파트)','010-6531-3581','CRolosIk@yahoo.com','회원','일반',1039);
Insert into tblMember (memberSeq,NAME,ID,PASSWORD,JUMIN,GENDER,POSTALCODE,ADDRESS,TEL,EMAIL,GRADE,ACCOUNTSTATUS,MILEAGE) values ('MB'||Member_Seq.nextVal,'장혁한','aly5699','PpWZXFn','771005','여자','6274','서울특별시 강남구 남부순환로381길 15  101동 1002호(도곡동  포스코트아파트)','010-2841-9654','dtmTtVs9@hanmail.net','회원','일반',9);
Insert into tblMember (memberSeq,NAME,ID,PASSWORD,JUMIN,GENDER,POSTALCODE,ADDRESS,TEL,EMAIL,GRADE,ACCOUNTSTATUS,MILEAGE) values ('MB'||Member_Seq.nextVal,'송경규','ami6170','lLbPF7Ezh41','700610','남자','21032','인천광역시 계양구 임학서로6번길 14  가동 503호(임학동  인우아파트)','010-1585-9104','dsepsoqm@hanmail.net','회원','일반',146);
Insert into tblMember (memberSeq,NAME,ID,PASSWORD,JUMIN,GENDER,POSTALCODE,ADDRESS,TEL,EMAIL,GRADE,ACCOUNTSTATUS,MILEAGE) values ('MB'||Member_Seq.nextVal,'장정희','amj4386','DywQWd','870922','남자','63249','제주특별자치도 제주시 아봉로 86  302호(아라이동  현임빌라)','010-0937-9179','BxJKOizp@yahoo.com','회원','일반',29);
Insert into tblMember (memberSeq,NAME,ID,PASSWORD,JUMIN,GENDER,POSTALCODE,ADDRESS,TEL,EMAIL,GRADE,ACCOUNTSTATUS,MILEAGE) values ('MB'||Member_Seq.nextVal,'김준규','aob0918','vvAe3IDdL3om','770619','여자','21318','인천광역시 부평구 후정동로 5  상가동 2층 1호(삼산동  대보아파트)','010-3338-8477','3owIVnJP@gmail.com','회원','일반',109);
Insert into tblMember (memberSeq,NAME,ID,PASSWORD,JUMIN,GENDER,POSTALCODE,ADDRESS,TEL,EMAIL,GRADE,ACCOUNTSTATUS,MILEAGE) values ('MB'||Member_Seq.nextVal,'임규혜','aoc9162','1mAVas','730609','남자','22241','인천광역시 미추홀구 주승로 253  102동 1410호(관교동  동부아파트)','010-5760-5202','0g2gq6F8@hanmail.net','회원','일반',2586);
Insert into tblMember (memberSeq,NAME,ID,PASSWORD,JUMIN,GENDER,POSTALCODE,ADDRESS,TEL,EMAIL,GRADE,ACCOUNTSTATUS,MILEAGE) values ('MB'||Member_Seq.nextVal,'한혁연','apm0145','psp8hjEhxkI3','900320','여자','25946','강원도 삼척시 도계읍 강원남부로 1734  가동 101호(삼마아파트)','010-3499-3558','DlUbsAjj@gmail.com','회원','정지',89);
Insert into tblMember (memberSeq,NAME,ID,PASSWORD,JUMIN,GENDER,POSTALCODE,ADDRESS,TEL,EMAIL,GRADE,ACCOUNTSTATUS,MILEAGE) values ('MB'||Member_Seq.nextVal,'송수현','aps1925','JB49P5','930412','여자','22520','인천광역시 동구 수문통로 35  지하 2호(송현동)','010-2087-1684','L9rcG7UX@naver.com','회원','일반',430);
Insert into tblMember (memberSeq,NAME,ID,PASSWORD,JUMIN,GENDER,POSTALCODE,ADDRESS,TEL,EMAIL,GRADE,ACCOUNTSTATUS,MILEAGE) values ('MB'||Member_Seq.nextVal,'김현기','apy0851','323XOY0gfogn','770505','여자','8029','서울특별시 양천구 오목로 36  406호(신월동  서울아파트)','010-0101-4424','5vVTWNLo@hanmail.net','회원','일반',1381);
Insert into tblMember (memberSeq,NAME,ID,PASSWORD,JUMIN,GENDER,POSTALCODE,ADDRESS,TEL,EMAIL,GRADE,ACCOUNTSTATUS,MILEAGE) values ('MB'||Member_Seq.nextVal,'최혜규','apy4611','znKnTi1','880103','남자','63224','제주특별자치도 제주시 남광북3길 28-2  나동 202호(이도이동  경남빌라)','010-9764-8347','l966Bj95@gmail.com','회원','일반',1482);
Insert into tblMember (memberSeq,NAME,ID,PASSWORD,JUMIN,GENDER,POSTALCODE,ADDRESS,TEL,EMAIL,GRADE,ACCOUNTSTATUS,MILEAGE) values ('MB'||Member_Seq.nextVal,'송현수','aqn3698','1upv2MMxb','960914','여자','7724','서울특별시 강서구 초록마을로10길 55  202호(화곡동  경남하이츠빌라)','010-9361-0239','lYtIi5bM@yahoo.com','회원','일반',762);
Insert into tblMember (memberSeq,NAME,ID,PASSWORD,JUMIN,GENDER,POSTALCODE,ADDRESS,TEL,EMAIL,GRADE,ACCOUNTSTATUS,MILEAGE) values ('MB'||Member_Seq.nextVal,'주기선','asl1849','FDDoiD73','950818','남자','42152','대구광역시 수성구 청수로1길 68  207호(중동  중동서울아파트)','010-4228-9107','a2unp3lM@yahoo.com','회원','일반',14768);
Insert into tblMember (memberSeq,NAME,ID,PASSWORD,JUMIN,GENDER,POSTALCODE,ADDRESS,TEL,EMAIL,GRADE,ACCOUNTSTATUS,MILEAGE) values ('MB'||Member_Seq.nextVal,'정한선','asq9111','85FuY6ndJ','991002','여자','44687','울산광역시 남구 번영로191번길 17  201호(신정동  경남골든빌라)','010-1939-6086','QXLpEmgy@yahoo.com','회원','일반',1093);
Insert into tblMember (memberSeq,NAME,ID,PASSWORD,JUMIN,GENDER,POSTALCODE,ADDRESS,TEL,EMAIL,GRADE,ACCOUNTSTATUS,MILEAGE) values ('MB'||Member_Seq.nextVal,'장준연','ats4865','ZJ5SDiR','700618','남자','21056','인천광역시 계양구 경명대로 1126  13동 312호(계산동  삼보아파트)','010-8208-4593','DzIglYDr@yahoo.com','회원','일반',417);
Insert into tblMember (memberSeq,NAME,ID,PASSWORD,JUMIN,GENDER,POSTALCODE,ADDRESS,TEL,EMAIL,GRADE,ACCOUNTSTATUS,MILEAGE) values ('MB'||Member_Seq.nextVal,'이혁장','auv6062','Az6ZCtBu','940412','여자','51685','경상남도 창원시 진해구 인사로38번길 8  경남빌라동 501호(제황산동  경남빌라)','010-5153-3232','q9OwcLBB@hanmail.net','회원','일반',11868);

-- 영상(동적)Video(O)
 set define off;
 insert into tblvideo values ('VS'||Video_seq.nextVal, '국내 최정상 스포츠영양사가 알려주는 "탄수화물"이란', '영양학', '2021-12-20', 'https://www.youtube.com/watch?v=yhfw8tIoZ4s&t=220s');
 insert into tblvideo values ('VS'||Video_seq.nextVal, '트레이너 출신 스포츠영양사가 알려주는 단백질 천하통일 총정리 1', '영양학', '2021-12-25', 'https://www.youtube.com/watch?v=9-9-cnqHG8Q');
 insert into tblvideo values ('VS'||Video_seq.nextVal, '운동 후 최적의 영양섭취 가이드(feat.기회의창)', '영양학', '2022-01-17', 'https://www.youtube.com/watch?v=FZsbF9PpluM');
 insert into tblvideo values ('VS'||Video_seq.nextVal, '[우수한 영양상담] 나트륨', '영양학', '2021-12-22', 'https://www.youtube.com/watch?v=XQ5V1NEO-R0');
 insert into tblvideo values ('VS'||Video_seq.nextVal, '기초부터 알아보는 우수한 영양상담 지방 ( feat.포화&불포화)', '영양학', '2021-12-13', 'https://www.youtube.com/watch?v=wOFtFfYBVSI');
 
 insert into tblvideo values ('VS'||Video_seq.nextVal, '단백질 보충제 선택의 모든것!', '보충제', '2021-12-22', 'https://www.youtube.com/watch?v=-yLtnBU42Vw');
 insert into tblvideo values ('VS'||Video_seq.nextVal, '약사가 선택한 단백질보충제, 동물성이냐 식물성이냐 그것이 알고싶다!', '보충제', '2021-01-02', 'https://www.youtube.com/watch?v=TKwIH9IvM6c');
 insert into tblvideo values ('VS'||Video_seq.nextVal, '종결) 영양제, 보조제는 딱 이것들만 드세요 !!!!!', '보충제', '2021-12-12', 'https://www.youtube.com/watch?v=8j58DptAB3w');
 insert into tblvideo values ('VS'||Video_seq.nextVal, '보충제 시장 1등급 고인물 스포츠영양사의 국산vs외국 단백질 보충제 전격비교', '보충제', '2021-12-05', 'https://www.youtube.com/watch?v=VnsTna_ZGBI');
 insert into tblvideo values ('VS'||Video_seq.nextVal, '김계란이 추천하는 운동 전,후 영양제', '보충제', '2021-12-27', 'https://www.youtube.com/watch?v=Dj3kYRr5zDo');
 
 insert into tblvideo values ('VS'||Video_seq.nextVal, '식단 이대로 해보세요. 식단 짜는 방법 !', '식단', '2021-12-27', 'https://www.youtube.com/watch?v=lTBPAjs2BtA');
 insert into tblvideo values ('VS'||Video_seq.nextVal, '최초 식단 공개! 다이어트 30년 노하우 공개! l 최고의 다이어트 Ep.1', '식단', '2021-12-27', 'https://www.youtube.com/watch?v=y4vZ44rGxUw');
 insert into tblvideo values ('VS'||Video_seq.nextVal, '무조건 감량 가능한 참가자들의 다이어트 식단공개', '식단', '2021-12-27', 'https://www.youtube.com/watch?v=Mt8ll1FACAA');
 insert into tblvideo values ('VS'||Video_seq.nextVal, '체지방 3% 만드는 대회식단 완벽 대 공개!', '식단', '2021-12-27', 'https://www.youtube.com/watch?v=nuEvLCD5j6c');
 insert into tblvideo values ('VS'||Video_seq.nextVal, '살 빼기 힘든 식단 vs 효과적인 다이어트식단 🔥63kg에서 44kg! 식단 공개', '식단', '2021-12-27', 'https://www.youtube.com/watch?v=AgX7yqQcb_k'); 

-- 상품 정보Product(O)
insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'닭가슴살 스테이크 오리지널','100g','닭가슴살',1500,999,'동글납작한 닭가슴살 스테이크에 불고기맛과 그릴링을 더해 그냥 먹어도 밥에 먹어도 맛있는 닭가슴살 스테이크!','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'닭가슴살 스테이크 호박맛','100g','닭가슴살',1570,999,'닭가슴살을 갈아서 동그랗게 만든 스테이크에 호박맛을 더해 건강한 달콤함과 영양을 동시에 UP!','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'닭가슴살 스테이크 고추맛','100g','닭가슴살',1570,999,'닭가슴살을 갈아서 동그랗게 만든 스테이크에 청양고추를 더해 매콤하면서도 깔끔한 맛을 선사합니다.','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'닭가슴살 스테이크 갈릭맛','100g','닭가슴살',1570,999,'닭가슴살을 갈아서 동그랗게 만든 스테이크에 국내산 마늘을 더해 건강한 깊은맛과 영양을 동시에 UP!','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'닭가슴살 스테이크 야채맛','100g','닭가슴살',1570,999,'동글납작한 닭가슴살 스테이크에 신선한 야채로 풍부해진 식감, 닭가슴살과 야채 두가지를 한번에!','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'소스 닭가슴살 스테이크 로스트 갈릭','150g','닭가슴살',2200,999,'부드러운 닭가슴살 스테이크에 소스를 듬~뿍! 입 안 가득 느껴지는 촉촉함','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'소스 닭가슴살 스테이크 매콤 토마토','150g','닭가슴살',2200,999,'부드러운 닭가슴살 스테이크에 소스를 듬~뿍! 입 안 가득 느껴지는 촉촉함','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'소스 닭가슴살 스테이크 토마토','150g','닭가슴살',2200,999,'부드러운 닭가슴살 스테이크에 소스를 듬~뿍! 입 안 가득 느껴지는 촉촉함','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'소스 닭가슴살 스테이크 자색고구마 까르보나라','150g','닭가슴살',2200,999,'부드러운 닭가슴살 스테이크에 소스를 듬~뿍! 입 안 가득 느껴지는 촉촉함','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'소스 닭가슴살 스테이크 흑마늘','150g','닭가슴살',2200,999,'부드러운 닭가슴살 스테이크에 소스를 듬~뿍! 입 안 가득 느껴지는 촉촉함','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'닭가슴살 한끼 스테이크 토마토','100g','닭가슴살',1960,999,'한끼 스테이크는 닭가슴살 제품을 넘어 하나의 요리 역할을 하기 위해 탄생한 제품입니다.','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'닭가슴살 한끼 스테이크 치즈','100g','닭가슴살',1960,999,'한끼 스테이크는 닭가슴살 제품을 넘어 하나의 요리 역할을 하기 위해 탄생한 제품입니다.','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'스팀 닭가슴살 마늘맛','100g','닭가슴살',1700,999,'시원~한 맛이 일품인 닭가슴살! 강한 양념 대신 담백하면서 은은한 마늘맛으로 풍부한 맛을 더한 닭가슴살!','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'스팀 닭가슴살 고추맛','100g','닭가슴살',1700,999,'깔끔~한 맛이 일품인 닭가슴살! 강한 양념 대신 매콤하고 청량한 고추맛으로 풍부한 맛!','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'소프트 닭가슴살 마늘','100g','닭가슴살',1900,999,'그 어디에도 없는 부드러움, 진짜 소프트 닭가슴살을 바로 맛있닭이 선보입니다.','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'소프트 닭가슴살 고추','100g','닭가슴살',1900,999,'그 어디에도 없는 부드러움, 진짜 소프트 닭가슴살을 바로 맛있닭이 선보입니다.','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'소프트 닭가슴살 탄두리','100g','닭가슴살',1900,999,'그 어디에도 없는 부드러움, 진짜 소프트 닭가슴살을 바로 맛있닭이 선보입니다.','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'저염 스팀 닭가슴살 오리지널','100g','닭가슴살',1700,999,'먹어도 먹어도 맛있고 먹어도 먹어도 질리지 않는, 맛있달 저염 스팀 닭가슴살을 즐겨보세요!','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'닭가슴살 큐브 마늘','100g','닭가슴살',1800,999,'닭가슴살 외의 재료를 최소화하고 맛있는 "맛"을 더한 닭가슴살! 강한 양념 대신 담백하면서 은은한 마늘향으로 풍부한 맛을 더한 닭가슴살!','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'닭가슴살 큐브 고추','100g','닭가슴살',1800,999,'닭가슴살 외의 재료를 최소화하고 맛있는 "맛"을 더한 닭가슴살! 담백한 닭가슴살에 매콤한 고추맛으로 청량감을 더!','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'씨푸드 다이어트 도시락(제주톳밥,쭈꾸미오징어)','250g','도시락',4800,999,'다채로운 해물로 점심 도시락을 꾸며볼까요~?','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'씨푸드 다이어트 도시락(제주톳밥,쭈꾸미새우)','250g','도시락',4800,999,'다채로운 해물로 점심 도시락을 꾸며볼까요~?','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'씨푸드 다이어트 도시락(해초밥,해물믹스)','250g','도시락',4800,999,'다채로운 해물로 점심 도시락을 꾸며볼까요~?','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'다이어트 도시락 (마늘소시지 볶음밥,소프트안심 오리지널)','210g','도시락',4300,999,'다이어트 도시락, 이제 아무거나 먹지말고 브랜드를 꼭 따져보세요','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'다이어트 도시락 (카무트 밥,소프트안심 마늘맛)','210g','도시락',4300,999,'다이어트 도시락, 이제 아무거나 먹지말고 브랜드를 꼭 따져보세요','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'다이어트 도시락 (제주톳보리밥,소시지볼 훈제맛)','210g','도시락',4300,999,'다이어트 도시락, 이제 아무거나 먹지말고 브랜드를 꼭 따져보세요','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'다이어트 도시락 (중화볶음밥,굴림만두 고기)','210g','도시락',4300,999,'다이어트 도시락, 이제 아무거나 먹지말고 브랜드를 꼭 따져보세요','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'다이어트 도시락 (황금볶음밥,굴림만두 김치)','210g','도시락',4300,999,'다이어트 도시락, 이제 아무거나 먹지말고 브랜드를 꼭 따져보세요','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'다이어트 도시락 (게살볶음밥,볼 깻잎맛)','도시락','210g',4300,999,'다이어트 도시락, 이제 아무거나 먹지말고 브랜드를 꼭 따져보세요','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'다이어트 도시락 (양송이볶음밥,스팀 고추맛)','210g','도시락',4300,999,'다이어트 도시락, 이제 아무거나 먹지말고 브랜드를 꼭 따져보세요','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'다이어트 도시락 (새우볶음밥,동그랑땡)','210g','도시락',4300,999,'다이어트 도시락, 이제 아무거나 먹지말고 브랜드를 꼭 따져보세요','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'다이어트 도시락 (카레볶음밥,닭가슴살 볼)','210g','도시락',4300,999,'다이어트 도시락, 이제 아무거나 먹지말고 브랜드를 꼭 따져보세요','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'다이어트 도시락 (연근우엉밥,스팀 마늘맛)','210g','도시락',4300,999,'다이어트 도시락, 이제 아무거나 먹지말고 브랜드를 꼭 따져보세요','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'맛있닭x제비표 더담은 도시락 큐브 마늘맛 , 연근우엉밥','275g','도시락',5400,999,'더담은 도시락은 든든하지만 균형있게, 집밥이 생각나는 국내산 100%쌀로 탄수화물은 건강하게 고루 섭취할 수있는 도시락입니다.','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'맛있닭x제비표 더담은 도시락 스팀 고추맛 , 곤드레나물밥','275g','도시락',5400,999,'더담은 도시락은 든든하지만 균형있게, 집밥이 생각나는 국내산 100%쌀로 탄수화물은 건강하게 고루 섭취할 수있는 도시락입니다.','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'맛있닭x제비표 더담은 도시락 스테이크 고추맛 , 야채현미밥','275g','도시락',5400,999,'더담은 도시락은 든든하지만 균형있게, 집밥이 생각나는 국내산 100%쌀로 탄수화물은 건강하게 고루 섭취할 수있는 도시락입니다.','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'맛있닭x제비표 더담은 도시락 스테이크 갈릭맛 , 퀴노아영양밥','275g','도시락',5400,999,'더담은 도시락은 든든하지만 균형있게, 집밥이 생각나는 국내산 100%쌀로 탄수화물은 건강하게 고루 섭취할 수있는 도시락입니다.','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'맛있닭x제비표 더담은 도시락 소시지 훈제맛 , 새우볶음밥','275g','도시락',5400,999,'더담은 도시락은 든든하지만 균형있게, 집밥이 생각나는 국내산 100%쌀로 탄수화물은 건강하게 고루 섭취할 수있는 도시락입니다.','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'더담은 닭가슴살 도시락 (다섯가지나물밥 , 갈릭스테이크소스 닭가슴살)','275g','도시락',5400,999,'더담은 도시락은 뻔한 도시락이 되지않기 위해 고민을 더해 만들었습니다.','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'더담은 닭가슴살 도시락 (부지깽이나물밥 ,닭가슴살볼 치즈맛)','275g','도시락',5400,999,'더담은 도시락은 뻔한 도시락이 되지않기 위해 고민을 더해 만들었습니다.','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'프레쉬홈 이지 샐러드 A type 90g','90g','야채류',2000,999,'이지샐러드는 세척과 손질이 되어있어 바로 먹어도 OK!','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'프레쉬홈 이지 샐러드 B type 90g','90g','야채류',2000,999,'이지샐러드는 세척과 손질이 되어있어 바로 먹어도 OK!','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'프레쉬홈 이지 샐러드 C type 90g','90g','야채류',2000,999,'이지샐러드는 세척과 손질이 되어있어 바로 먹어도 OK!','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'프레쉬홈 이지 샐러드 D type 90g','90g','야채류',2000,999,'이지샐러드는 세척과 손질이 되어있어 바로 먹어도 OK!','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'프레쉬홈 이지 샐러드 E type 90g','90g','야채류',2000,999,'이지샐러드는 세척과 손질이 되어있어 바로 먹어도 OK!','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'1am 알뜰 Daily 샐러드 옐로우 100g','100g','야채류',2000,999,'세워놓고 섭취할 수 있는 스탠딩 파우치의 알뜰 데일리 샐러드는, 소스만 붓고 바로 즐길 수 있는 간편함까지 선사해요.','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'1am 알뜰 Daily 샐러드 그린 100g','100g','야채류',2000,999,'세워놓고 섭취할 수 있는 스탠딩 파우치의 알뜰 데일리 샐러드는, 소스만 붓고 바로 즐길 수 있는 간편함까지 선사해요.','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'1am 알뜰 Daily 샐러드 레드 100g','100g','야채류',2000,999,'세워놓고 섭취할 수 있는 스탠딩 파우치의 알뜰 데일리 샐러드는, 소스만 붓고 바로 즐길 수 있는 간편함까지 선사해요.','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'1am 알뜰 Daily 샐러드 베이비그린 100g','100g','야채류',2000,999,'세워놓고 섭취할 수 있는 스탠딩 파우치의 알뜰 데일리 샐러드는, 소스만 붓고 바로 즐길 수 있는 간편함까지 선사해요.','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'1am 알뜰 Daily 샐러드 퍼플 100g','100g','야채류',2000,999,'세워놓고 섭취할 수 있는 스탠딩 파우치의 알뜰 데일리 샐러드는, 소스만 붓고 바로 즐길 수 있는 간편함까지 선사해요.','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'1am 알뜰 Daily 스무디 100g','100g','야채류',2000,999,'과대포장 없이 심플한 패키지는 알뜰 그린 스무디를 부담없는 가격으로 세상에 태어날 수 있게 한 일등 공신이죠.','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'프레쉬홈 그린 샐러드 100g','100g','야채류',2000,999,'프레시홈 샐러드는 계약농장에서 직접 재배하여 키운 샐러드로 바로바로 만들어 드립니다.','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'프레쉬홈 야채믹스 그린 샐러드 100g','100g','야채류',2000,999,'프레시홈 샐러드는 계약농장에서 직접 재배하여 키운 샐러드로 바로바로 만들어 드립니다.','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'프레쉬홈 파프리카 그린 샐러드 110g','110g','야채류',2000,999,'프레시홈 샐러드는 계약농장에서 직접 재배하여 키운 샐러드로 바로바로 만들어 드립니다.','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'프레쉬홈 자몽 그린 샐러드 140g','140g','야채류',2000,999,'프레시홈 샐러드는 계약농장에서 직접 재배하여 키운 샐러드로 바로바로 만들어 드립니다.','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'프레쉬홈 리코타치즈 샐러드 185g','140g','야채류',2000,999,'프레시홈 샐러드는 계약농장에서 직접 재배하여 키운 샐러드로 바로바로 만들어 드립니다.','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'프레쉬홈 파인애플 샐러드 190g','190g','야채류',2000,999,'프레시홈 샐러드는 계약농장에서 직접 재배하여 키운 샐러드로 바로바로 만들어 드립니다.','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'프레쉬홈 파프리카,양파 샐러드 180g','180g','야채류',2000,999,'프레시홈 샐러드는 계약농장에서 직접 재배하여 키운 샐러드로 바로바로 만들어 드립니다.','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'바디나인 내가몸짱이될 라디치오 샐러드 100g','100g','야채류',2000,999,'입맛따라,취향따라 골라 먹을 수 있는 5가지 맞춤형 토핑이 7가지 신선채소와 함께 어우러져 맛있고 건강한 한 끼를 전합니다.','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'바디나인 내가몸짱이될 로메인 샐러드 100g','100g','야채류',2000,999,'입맛따라,취향따라 골라 먹을 수 있는 5가지 맞춤형 토핑이 7가지 신선채소와 함께 어우러져 맛있고 건강한 한 끼를 전합니다.','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'라이언 포대유청 단백질 보충제 WPC 2kg','2kg','단백질보충제',39000,999,'좋은 근육을 위한 모든 조건을 갖추다','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'프로틴어스 라이거 프로틴 맥스 복합단백질 보충제 1.82kg','1.82kg','단백질보충제',65000,999,'한번에 끝내는 강력한 보충제','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'프로틴어스 베어스 메가 게이너 보충제 4kg','4kg','단백질보충제',78000,999,'고칼로리 게이너 보충제','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'프로틴어스 맛있는 일상 4242 쉐이크 초코 50g','50g','단백질보충제',3960,999,'밥 먹을 시간도 없이 매일매일 바쁜 현대인을 위해','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'프로틴어스 맛있는 일상 4242 쉐이크 고구마 50g','50g','단백질보충제',3960,999,'밥 먹을 시간도 없이 매일매일 바쁜 현대인을 위해','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'프로틴어스 맛있는 일상 4242 쉐이크 녹차 50g','50g','단백질보충제',3960,999,'밥 먹을 시간도 없이 매일매일 바쁜 현대인을 위해','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'프로틴어스 맛있는 일상 4242 쉐이크 딸기요거트 50g','50g','단백질보충제',3960,999,'밥 먹을 시간도 없이 매일매일 바쁜 현대인을 위해','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'프로틴어스 맛있는 일상 4242 쉐이크 쿠키앤크림 50g','50g','단백질보충제',3960,999,'밥 먹을 시간도 없이 매일매일 바쁜 현대인을 위해','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'타브카 에너지 드링크 오리지널 355ml','355ml','단백질보충제',1200,999,'칼로리는 LOW! 에너지는 HIGH! 필수성분만 담은 저칼로리 에너지 드링크','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'타브카 에너지 드링크 버스트 355ml','355ml','단백질보충제',1200,999,'칼로리는 LOW! 에너지는 HIGH! 필수성분만 담은 저칼로리 에너지 드링크','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'[락토프리 고단백 프로틴 파우더] 퍼펙트 파워쉐이크 아이솔레이트','1,89kg','단백질보충제',69900,999,'운동의 완성 퍼펙트 파워쉐이크','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'칼로바이 퍼펙트파워쉐이크 보충제 초코맛 2kg','2kg','단백질보충제',68700,999,'먹는 것까지 운동이다!! 운동의 완성 퍼펙트 파워쉐이크','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'BSN Syntha-6 울트라 프리미엄 프로틴 매트릭스 딸기 밀크셰이크 1.32kg','1.32kg','단백질보충제',55400,999,'먹는 것까지 운동이다!! ','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'BSN 신타-6 울트라 프리미엄 린 머슬 프로틴 파우더 초콜렛 땅콩 버터 1.32 kg','1.32kg','단백질보충제',55400,999,'먹는 것까지 운동이다!! ','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'BSN Syntha-6 울트라 프리미엄 단백질 구성 쿠키 앤 크림 1.32kg','1.32kg','단백질보충제',55400,999,'먹는 것까지 운동이다!! ','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'BSN Syntha-6 콜드 스톤 크리머리 쿠키 돈트 유 원 썸 1.17kg','1.17kg','단백질보충제',55400,999,'먹는 것까지 운동이다!! ','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'BSN Syntha-6 Isolate 단백질 파우더 드링크 믹스 초콜릿 밀크쉐이크 912 g','912g','단백질보충제',60000,999,'먹는 것까지 운동이다!! ','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'BSN 신타-6 콜드 스톤 크리머리 저먼초콜레이트카케 1.17kg','1.17kg','단백질보충제',55400,999,'먹는 것까지 운동이다!! ','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'Optimum Nutrition Gold Standard 100% Whey 초콜릿 피넛 버터 907g','907g','단백질보충제',55400,999,'먹는 것까지 운동이다!! ','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'Optimum Nutrition Gold Standard 100% Whey 딸기 및 크림 899g','899g','단백질보충제',55400,999,'먹는 것까지 운동이다!! ','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'뉴트리커먼 XL- 엘-아르기닌 300g','300g','기타영양제',18900,999,'바쁜 일상 언제 다 챙겨 드실건가요 ? 빠르고 간편하게 고함량 아르기닌을 즐겨보세요~','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'뉴트리커먼 초임계 루테인 아스타잔틴 60캡슐','30g','기타영양제',26900,999,'황금같은 내 눈을 위한 단 하나의 초이스','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'뉴트리커먼 먹는 히알루론산 300g','300g','기타영양제',17900,999,'기초탄탄! 속부터 잡는 촉촉함! 젤리처럼 피부가 탱글~','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'뉴트리커먼 포스트바이오틱스 60g','60g','기타영양제',13900,999,'온 가족이 먹을 수 있는 패밀리 유산균','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'뉴트리커먼 먹는 알로에베라겔 300g','300g','기타영양제',21900,999,'이제 알로에 먹고 장 건강, 피부건강, 면역력까지 지키세요!','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'뉴트리커먼 쏘팔메토 옥타코사놀 60정','48g','기타영양제',33900,999,'남자의 자존심! 뉴트리커먼이 관리해드리겠습니다!','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'뉴트리커먼 흡수력 높은 블랙 젤라틴 마카 72g','72g','기타영양제',27900,999,'남자에게 정말 좋은 성분들만 가득 모았습니다.','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'근본식품 활 / 데일리 아연 활력 부스터 면역UP 80ml','80ml','기타영양제',33600,999,'이제 지친 몸을 깨울 시간입니다.','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'인테이크 포뮬러 멀티비타민미네랄 포우먼 (30정)','36g','기타영양제',16000,999,'비타민·미네랄 이제 가볍게 꺼내드세요!','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'인테이크 포뮬러 멀티비타민미네랄 포맨 (30정)','36g','기타영양제',16000,999,'비타민·미네랄 이제 가볍게 꺼내드세요!','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'칼로바이 ACTIVE L-아르기닌 1000 144g','144g','기타영양제',14900,999,'기력과 활력을 위한 칼로바이의 솔루션','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'세노비스 마그네슘','144g','기타영양제',28000,999,'신경과 근육 기능 유지는 물론! 체내 에너지 생성에 도움까지','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'세노비스 밀크씨슬+','144g','기타영양제',38000,999,'간 건강에 도움을 줄 수 있음 에너지 대사 및 생성에 필요','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'라이프포스 컷팅샷 150g','150g','기타영양제',23000,999,'바쁜 일상 속 나를 위한 컷팅 타임','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'체조시간 황금구렁이 차전자피 식이섬유 100g','100g','기타영양제',27900,999,'매일 규칙적인 배변과 뒤끝 없는 개운함','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'리얼진 늘편한day 1박스 80g','80g','기타영양제',17900,999,'늘편한 데이로 속편한 하루를','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'유기농 밀크씨슬','30g','기타영양제',39000,999,'하루 1정으로 간편하게','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'얼라이브 원스데일리 포맨 멀티 비타민','97.9g','기타영양제',35000,999,'한 알에 가득 채웠습니다.','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'얼라이브 원스데일리 포 우먼 멀티 비타민','115g','기타영양제',35000,999,'한 알에 가득 채웠습니다.','판매중');

insert into tblProduct (productSeq, productName, capacity, category, price, inventory, productDescription, salesStatus)
	values ('PD' || product_seq.nextVal,'익스트림 블랙마카 1600','97.2g','기타영양제',47500,999,'한 알에 가득 채웠습니다.','판매중');


-- 문의(O)
insert into tblQA (QASeq, QASubject, QAContent, QAAnswer, QACategory, memberSeq)
    values ('QA'||QA_seq.nextVal,
    '포장',
    '식품을 주문했는데 포장이 어떻게 돼서 오나요? 상할 염려 없나요?',
    '안녕하세요 고객님! 식품 아이스팩과 함께 보냉박스에 포장되어 배송이 완료될때까지 제품상태는 그대로 보존됩니다. 다만 배송완료 후 고객님이 상품을 바로 수령하지 않고 제품이 방치될 경우 상할 수 있으니 주의바랍니다.',
    '상품문의',
    'MB1');
insert into tblQA (QASeq, QASubject, QAContent, QAAnswer, QACategory, memberSeq)
    values ('QA'||QA_seq.nextVal,
    '회원정보 주소지랑 다른 수령지',
    '다른데로 선물보내려고하는데 회원정보 주소랑 배송지랑 다르게 설정가능한가요?',
    '안녕하세요 고객님! 주문서 작성 시 수령지를 상품을 받아보실 곳으로 설정 가능합니다. 감사합니다.',
    '배송문의',
    'MB2');
insert into tblQA (QASeq, QASubject, QAContent, QAAnswer, QACategory, memberSeq)
    values ('QA'||QA_seq.nextVal,
    '취소신청 철회',
    '취소신청 철회가능하나요?',
    '안녕하세요. 안타깝게도 고객님의 취소정보가 확인되지 않고 있어 번거로우시겠지만 재주문을 이용해주시면 감사하겠습니다.',
    '기타문의',
    'MB3');
insert into tblQA (QASeq, QASubject, QAContent, QAAnswer, QACategory, memberSeq)
    values ('QA'||QA_seq.nextVal,
    '주문했습니다',
    '현재CJ대한통운택배 파업중입니다. 타 택배사 이용하여 발송부탁드립니다.',
    '안녕하세요. 고객님이 상품을 빨리 받아보시는데 지장 없도록 처리 하겠습니다. 감사합니다.',
    '배송문의',
    'MB4');
insert into tblQA (QASeq, QASubject, QAContent, QAAnswer, QACategory, memberSeq)
    values ('QA'||QA_seq.nextVal,
    '유통기한',
    '많은 제품이 있는데 평균 유통기한은 어느정도로 배송되나요?',
    '안녕하세요. 냉장식품의 경우 평균 1개월, 냉동식품의 경우 평균 4개월 이상으로 출고되고 있습니다.',
    '상품문의',
    'MB5');
insert into tblQA (QASeq, QASubject, QAContent, QAAnswer, QACategory, memberSeq)
    values ('QA'||QA_seq.nextVal,
    '가격',
    '가격이 왜자꼬 올라요?',
    '안녕하세요 고객님. 제품 가격은 고정가가아니여서 변동이 있을 수 있습니다. 다만 고객님이 저렴한 제품을 만나실 수 있도록 다양한 할인이벤트를 진행 또는 준비중이니 많은 관심부탁드립니다. 감사합니다.',
    '기타문의',
    'MB6');
insert into tblQA (QASeq, QASubject, QAContent, QAAnswer, QACategory, memberSeq)
    values ('QA'||QA_seq.nextVal,
    '홍보',
    '상품문의에 타사이트 홍보하는 사람이 있습니다.',
    '안녕하세요 고객님. 타사이트홍보글을 접해 저희 쇼핑몰 이용 시 불쾌하셨을 고객님에게 죄송하다는 말씀 드립니다. 홍보글에 불편을 느끼시지 않도록 지속적인 모니터링을 강화하겠습니다. 감사드립니다.',
    '신고문의',
    'MB7');
insert into tblQA (QASeq, QASubject, QAContent, QAAnswer, QACategory, memberSeq)
    values ('QA'||QA_seq.nextVal,
    '탈퇴',
    '회원탈퇴를 하려는데 적립된 포인트는 어떻게 되나요?',
    '안녕하세요 고객님. 회원탈퇴 시 적립된 포인트는 소멸되는 점 참고부탁드립니다. 감사합니다.',
    '계정문의',
    'MB8');
insert into tblQA (QASeq, QASubject, QAContent, QAAnswer, QACategory, memberSeq)
    values ('QA'||QA_seq.nextVal,
    '탈퇴',
    '회원탈퇴를 하려는데 적립된 포인트는 어떻게 되나요?',
    '안녕하세요 고객님. 회원탈퇴 시 적립된 포인트는 소멸되는 점 참고부탁드립니다. 감사합니다.',
    '계정문의',
    'MB9');    
insert into tblQA (QASeq, QASubject, QAContent, QAAnswer, QACategory, memberSeq)
    values ('QA'||QA_seq.nextVal,
    '꼭',
    '꼭 오리지널로 보내주세요. 저번에 다른맛으로 잘못 보내셔서 환불은 받았는데 냉동실에 아직 그대로있습니다.',
    '안녕하세요 고객님. 불편을 드린점 죄송합니다. 고객님이 원하는 제품을 받아보실 수 있도록 꼼꼼하게 점검하여 보내드리겠습니다. 감사합니다.',
    '상품문의',
    'MB10');        
insert into tblQA (QASeq, QASubject, QAContent, QAAnswer, QACategory, memberSeq)
    values ('QA'||QA_seq.nextVal,
    '전자렌지',
    '전자렌지에 데워 먹나요?',
    '안녕하세요 고객님. 상품정보가 확인되지 않고 있습니다. 해당 상품 페이지에서 문의를 이용하시거나 개별문의시 궁금하신 상품의 정보를 함께 기재해서 문의해주시면 감사하겠습니다.',
    '상품문의',
    'MB11');
insert into tblQA (QASeq, QASubject, QAContent, QAAnswer, QACategory, memberSeq)
    values ('QA'||QA_seq.nextVal,
    '첫주문',
    '첫주문합니다. 먹어보고 괜찮으면 재주문하려고요. 꼼꼼하게 확인 후 빠른배송 부탁드립니다~',
    '안녕하세요 고객님. 첫주문 감사드리며 고객님이 만족하실 수 있도록 꼼꼼하게 제품 확인 후 빠른발송처리진행하겠습니다. 감사합니다.',
    '기타문의',
    'MB12');
insert into tblQA (QASeq, QASubject, QAContent, QAAnswer, QACategory, memberSeq)
    values ('QA'||QA_seq.nextVal,
    '묶음상품',
    '묶음상품 할인율은 어떻게 책정되는거죠?',
    '안녕하세요 고객님. 묶음상품 할인율의 기준은 고정된 것이 아니고 재고수량과 판매수요에 의해 가변적인 할인율을 적용하고 있으니 참고바랍니다.',
    '기타문의',
    'MB13');    
insert into tblQA (QASeq, QASubject, QAContent, QAAnswer, QACategory, memberSeq)
    values ('QA'||QA_seq.nextVal,
    '로그인',
    '가끔 로그인이 한번에 잘 안돼요.',
    '안녕하세요 고객님. 쇼핑몰이용에 불편을 드려서 죄송합니다. 더 나은 환경에서 쾌적하게 쇼핑몰을 이용할 수 있도록 해당사항 관련부서에 이관하여 조치하겠습니다. 감사합니다.',
    '계정문의',
    'MB14');   
insert into tblQA (QASeq, QASubject, QAContent, QAAnswer, QACategory, memberSeq)
    values ('QA'||QA_seq.nextVal,
    '추천상품',
    '추천상품의 기준이 뭔가요?',
    '안녕하세요 고객님. 저희 쇼핑몰에 등록된 고객님의 바디정보를 기초로하여 다이어트 목적에 맞는 영양소가 들어간 제품이 우선추천되는 형식으로 추천상품이 제공됩니다. 감사합니다.',
    '상품문의',
    'MB15');
insert into tblQA (QASeq, QASubject, QAContent, QAAnswer, QACategory, memberSeq)
    values ('QA'||QA_seq.nextVal,
    '바디정보',
    '제 바디정보가 삭제된것같아요.',
    '안녕하세요 고객님. 확인결과 고객님의 바디정보는 소중히 보관되고 있으며 일시적으로 페이지 접속이 원할하지 않았던 것 같습니다. 불편을 드려 죄송합니다.',
    '계정문의',
    'MB16');
insert into tblQA (QASeq, QASubject, QAContent, QAAnswer, QACategory, memberSeq)
    values ('QA'||QA_seq.nextVal,
    '영양소정보',
    '영양소정보가 작아서 잘 안보여요.',
    '안녕하세요 고객님. 쇼핑몰 이용에 불편을 드려 죄송합니다. 관련내용 담당부서로 전달하여 시스템개선사항에 반영될 수 있도록 노력하겠습니다.',
    '기타문의',
    'MB17');
insert into tblQA (QASeq, QASubject, QAContent, QAAnswer, QACategory, memberSeq)
    values ('QA'||QA_seq.nextVal,
    '마일리지',
    '포인트는 어떻게 사용하나요?',
    '안녕하세요 고객님. 결제과정에서 포인트사용을 적용하시면 회원님이 보유한 포인트가 자동적용되어 포인트 만큼 감액된 최종결제금액을 확인하실 수 있습니다. 감사합니다. ',
    '기타문의',
    'MB18');
insert into tblQA (QASeq, QASubject, QAContent, QAAnswer, QACategory, memberSeq)
    values ('QA'||QA_seq.nextVal,
    '배송',
    '오늘 오전에 주문했는데 내일 받아볼 수 있나요?',
    '안녕하세요 고객님. 평균 오전 주문건은 오후에 택배사에 인계되어 평균 1~2일에 배송기간이 소요되나 재고현황 및 택배사의 상황에 따라 변동이 있을 수 있다는 점을 안내드립니다. 감사합니다.',
    '배송문의',
    'MB19');    
insert into tblQA (QASeq, QASubject, QAContent, QAAnswer, QACategory, memberSeq)
    values ('QA'||QA_seq.nextVal,
    '제품추천',
    '제품추천에 고려되는 사항은 어떤것들이 있나요?',
    '안녕하세요 고객님. 고객님의 신장, 체중, 성별, 운동목적 등에 따라 필요한 영양소가 산출되어 추천됩니다. 감사합니다.',
    '기타문의',
    'MB20');    
insert into tblQA (QASeq, QASubject, QAContent, QAAnswer, QACategory, memberSeq)
    values ('QA'||QA_seq.nextVal,
    '음',
    '식품이나 영양제말고 에어프라이어같은건 안파나요?',
    '안녕하세요 고객님. 아쉽게도 현재는 판매하고 있지 않으나 관련부서에 전달해서 고객님의 소중한 의견이 반영될 수 있도록 검토해보겠습니다. 감사합니다.',
    '기타문의',
    'MB1');   
insert into tblQA (QASeq, QASubject, QAContent, QAAnswer, QACategory, memberSeq)
    values ('QA'||QA_seq.nextVal,
    '탄산수!',
    '탄산수도 같이 팔았으면 좋겠네요.',
    '안녕하세요 고객님. 소중한 의견 정말 감사드립니다. 쇼핑몰 운영에 적극반영할 수 있도록 하겠습니다.',
    '상품문의',
    'MB2');   
--------------------------------------------------------------------------------------------------------------------------------------------
insert into tblQA (QASeq, QASubject, QAContent, QAAnswer, QACategory, memberSeq)
    values ('QA'||QA_seq.nextVal,
    '배송',
    '배송이 너무 느립니다. 이미 상했을 듯 한데 환불해주세요.',
    default,
    '배송문의',
    'MB1');
insert into tblQA (QASeq, QASubject, QAContent, QAAnswer, QACategory, memberSeq)
    values ('QA'||QA_seq.nextVal,
    '수량부족',
    '구매한 수량보다 적게 왔는데 확인해주세요.',
    default,
    '기타문의',
    'MB2');
insert into tblQA (QASeq, QASubject, QAContent, QAAnswer, QACategory, memberSeq)
    values ('QA'||QA_seq.nextVal,
    '배송!!',
    '주문했는데 아직도 배송중인데 왜이렇게 안오나요?',
    default,
    '배송문의',
    'MB3');
insert into tblQA (QASeq, QASubject, QAContent, QAAnswer, QACategory, memberSeq)
    values ('QA'||QA_seq.nextVal,
    '송장번호',
    '제가 주문한 상품 송장번호좀 알려주세요.',
    default,
    '배송문의',
    'MB4');
insert into tblQA (QASeq, QASubject, QAContent, QAAnswer, QACategory, memberSeq)
    values ('QA'||QA_seq.nextVal,
    '택배사',
    '어느 택배사로 배송되나요?',
    default,
    '배송문의',
    'MB5');
insert into tblQA (QASeq, QASubject, QAContent, QAAnswer, QACategory, memberSeq)
    values ('QA'||QA_seq.nextVal,
    '수령지',
    '주문할때 수령지 다른주소로 적었는지 기억이 잘 안나요. 확인좀해주세요.',
    default,
    '배송문의',
    'MB6');
insert into tblQA (QASeq, QASubject, QAContent, QAAnswer, QACategory, memberSeq)
    values ('QA'||QA_seq.nextVal,
    '상품',
    '주문하지 않은 상품을 받았는데 확인해주세요.',
    default,
    '배송문의',
    'MB7');
insert into tblQA (QASeq, QASubject, QAContent, QAAnswer, QACategory, memberSeq)
    values ('QA'||QA_seq.nextVal,
    '상품',
    '수령지상세설정에서 문앞으로 안적은거 같은데 수령지주소문앞배송으로 추가좀 해주세요.',
    default,
    '배송문의',
    'MB8');
insert into tblQA (QASeq, QASubject, QAContent, QAAnswer, QACategory, memberSeq)
    values ('QA'||QA_seq.nextVal,
    '반품',
    '반품하려는데 어느 택배사에서 가져가나요?',
    default,
    '배송문의',
    'MB9');
insert into tblQA (QASeq, QASubject, QAContent, QAAnswer, QACategory, memberSeq)
    values ('QA'||QA_seq.nextVal,
    '반품',
    '제 마일리지가 얼마나 사용되었는지 알려주세요.',
    default,
    '기타문의',
    'MB10');
--------------------------------------------------------------------------------------------------------------------------------------------
insert into tblQA (QASeq, QASubject, QAContent, QAAnswer, QACategory, memberSeq)
    values ('QA'||QA_seq.nextVal,
    '결제',
    '제가 주문한거 얼마나 할인됐나요?',
    default,
    '상품문의',
    'MB11');
insert into tblQA (QASeq, QASubject, QAContent, QAAnswer, QACategory, memberSeq)
    values ('QA'||QA_seq.nextVal,
    '?',
    '다이어트 식품 맞나요? 살찔 것 같은 맛인데요',
    default,
    '상품문의',
    'MB12');
insert into tblQA (QASeq, QASubject, QAContent, QAAnswer, QACategory, memberSeq)
    values ('QA'||QA_seq.nextVal,
    '칼로리',
    '이거 칼로리가 어떻게 되나요?',
    default,
    '상품문의',
    'MB13');
insert into tblQA (QASeq, QASubject, QAContent, QAAnswer, QACategory, memberSeq)
    values ('QA'||QA_seq.nextVal,
    '영양정보',
    '이 제품 영양정보좀 알려주세요.',
    default,
    '상품문의',
    'MB14');
insert into tblQA (QASeq, QASubject, QAContent, QAAnswer, QACategory, memberSeq)
    values ('QA'||QA_seq.nextVal,
    '이 제품',
    '이 제품 데우지 않고 그냥 샐러드에 넣어 먹어도 되나요?',
    default,
    '상품문의',
    'MB15');
insert into tblQA (QASeq, QASubject, QAContent, QAAnswer, QACategory, memberSeq)
    values ('QA'||QA_seq.nextVal,
    '추천',
    '제가 먹어보고 만족해서 헬스장 회원들한테 제품추천좀 하고싶은데 제가 산 제품 재고가 어느정도 있을까요?',
    default,
    '상품문의',
    'MB16');    
insert into tblQA (QASeq, QASubject, QAContent, QAAnswer, QACategory, memberSeq)
    values ('QA'||QA_seq.nextVal,
    '내용량',
    '제가 산거 한팩에 양이 어떻게 되나요?',
    default,
    '상품문의',
    'MB17');
insert into tblQA (QASeq, QASubject, QAContent, QAAnswer, QACategory, memberSeq)
    values ('QA'||QA_seq.nextVal,
    '상품',
    '제가 산 제품 탄,단,지 함량 정보좀 알려주세요.',
    default,
    '상품문의',
    'MB18');
insert into tblQA (QASeq, QASubject, QAContent, QAAnswer, QACategory, memberSeq)
    values ('QA'||QA_seq.nextVal,
    '단백질',
    '단백질이 많이 들어가 있는 제품군 추천좀요',
    default,
    '상품문의',
    'MB19');
insert into tblQA (QASeq, QASubject, QAContent, QAAnswer, QACategory, memberSeq)
    values ('QA'||QA_seq.nextVal,
    '영양제',
    '최대한 골고루 영양소가 들어있는 영양제가 어떤건가요?',
    default,
    '상품문의',
    'MB20');



-- 고객의소리(O) tblCSVoice
insert into tblCSVoice (CSVSeq, CSVSubject, CSVContent, memberSeq)
    values ('CV'||CSVoice_seq.nextVal, '서비스칭찬',
    '안녕하세요! 이번에 저희 헬스회원분들과 트레이닝 일정 계획중에 다이어트 관련 식품을 대량 구매해야할 일이 있었는데 다행히 묶음상품 할인율이 좋아서 대량으로 구매하면서도 가격적인 부분에서 타쇼핑몰보다 부담이 덜 했던 것 같습니다.! 앞으로도 묶음할인 및 할인이벤트를 많이했으면 좋겠네요!!',
    'MB1');
insert into tblCSVoice (CSVSeq, CSVSubject, CSVContent, memberSeq)
    values ('CV'||CSVoice_seq.nextVal, '시스템개선',
    '어떤 상품이 저한테 좋은지 잘 모르겠어요 식품관련정보를 습득하지 않아도 선택하는데 지장이 없도록 저에게 맞는 상품 추천을 좀 더 강화했으면 좋겠습니다.',
    'MB2');
insert into tblCSVoice (CSVSeq, CSVSubject, CSVContent, memberSeq)
    values ('CV'||CSVoice_seq.nextVal, '시스템개선',
    '제가 평소에 즐겨먹는 상품의 구매수량정보를 참고해서 다먹을때가 되면 자동주문알림을 해주는게 있으면 편할것같아요.',
    'MB3');
insert into tblCSVoice (CSVSeq, CSVSubject, CSVContent, memberSeq)
    values ('CV'||CSVoice_seq.nextVal, '시스템(PC/Mobile)오류 제보',
    '아이디저장 설정을 했는데도 가끔 아이디저장이 금방 풀려요. 고쳐주세요',
    'MB4');
insert into tblCSVoice (CSVSeq, CSVSubject, CSVContent, memberSeq)
    values ('CV'||CSVoice_seq.nextVal, '시스템(PC/Mobile)오류 제보',
    '상품url을 복사해놨다가 나중에 구매할려고 페이지를 여니까 페이지를 찾을 수 없다고 떠요.',
    'MB5');
insert into tblCSVoice (CSVSeq, CSVSubject, CSVContent, memberSeq)
    values ('CV'||CSVoice_seq.nextVal, '서비스칭찬',
    '문의하면 답변 속도도 빠르고 배송도 빠르고 상품 품질도 좋아요 전체적으로 너무 만족합니다!!',
    'MB6');
insert into tblCSVoice (CSVSeq, CSVSubject, CSVContent, memberSeq)
    values ('CV'||CSVoice_seq.nextVal, '서비스칭찬',
    '제 신체변화를 기록하고 한눈에 확인할 수 있다는게 너무 좋아요!! 여기 쇼핑몰 이용할때면 다이어트 의욕이 셈솟네요!!',
    'MB7');
insert into tblCSVoice (CSVSeq, CSVSubject, CSVContent, memberSeq)
    values ('CV'||CSVoice_seq.nextVal, '서비스칭찬',
    '덕분에 체중감량에 성공했습니다!! 건강보조식품에 대한 이해가 별로 없었는데 상품추천이 잘 되어있어서 별 어려움없이 접근할 수 있었어요!',
    'MB8');
insert into tblCSVoice (CSVSeq, CSVSubject, CSVContent, memberSeq)
    values ('CV'||CSVoice_seq.nextVal, '시스템개선',
    '구매포인트좀 더 팍팍 주시죠?',
    'MB9');
insert into tblCSVoice (CSVSeq, CSVSubject, CSVContent, memberSeq)
    values ('CV'||CSVoice_seq.nextVal, '서비스칭찬',
    '유통기한이 넉넉해서 좋아요!! 앞으로도 유통기한 넉넉한 제품으로 부탁드릴게요',
    'MB10');
insert into tblCSVoice (CSVSeq, CSVSubject, CSVContent, memberSeq)
    values ('CV'||CSVoice_seq.nextVal, '시스템개선',
    '제 바디정보를 입력하는 페이지 디자인이 좀 더 예뻤으면 좋겠어요.',
    'MB11');
insert into tblCSVoice (CSVSeq, CSVSubject, CSVContent, memberSeq)
    values ('CV'||CSVoice_seq.nextVal, '시스템(PC/Mobile)오류 제보',
    '모바일 접속 시 화면확대하면 상품이미지가 너무 깨지는거 같아요',
    'MB12');
insert into tblCSVoice (CSVSeq, CSVSubject, CSVContent, memberSeq)
    values ('CV'||CSVoice_seq.nextVal, '시스템개선',
    '다이어트를 자극하는 컬러로 쇼핑몰을 꾸미면 더 좋을것같아요',
    'MB13');
insert into tblCSVoice (CSVSeq, CSVSubject, CSVContent, memberSeq)
    values ('CV'||CSVoice_seq.nextVal, '시스템(PC/Mobile)오류 제보',
    '가끔 사이트가 너무 버벅임 답답함',
    'MB14');
insert into tblCSVoice (CSVSeq, CSVSubject, CSVContent, memberSeq)
    values ('CV'||CSVoice_seq.nextVal, '시스템개선',
    '제 바디정보를 입력하고 관리할 수 있는 기능이 너무 좋아서 제 계정으로 친구정보도 같이 관리 해주고싶은데 ID당 한사람이 정보밖에 입력을 할 수 없어서 불편해요',
    'MB15');
insert into tblCSVoice (CSVSeq, CSVSubject, CSVContent, memberSeq)
    values ('CV'||CSVoice_seq.nextVal, '시스템개선',
    '리뷰참여 시 포인트를 더 적립해줬으면 좋겠습니다.',
    'MB16');
insert into tblCSVoice (CSVSeq, CSVSubject, CSVContent, memberSeq)
    values ('CV'||CSVoice_seq.nextVal, '시스템개선',
    '커뮤니티나 소모임을 구성할 수 있는 게시판이 있어서 다이어트하는분들끼리 같이 열정을 나눌 수 있으면 좋겠습니다.',
    'MB17');
insert into tblCSVoice (CSVSeq, CSVSubject, CSVContent, memberSeq)
    values ('CV'||CSVoice_seq.nextVal, '시스템개선',
    '커뮤니티나 소모임을 구성할 수 있는 게시판이 있어서 다이어트하는분들끼리 같이 열정을 나눌 수 있으면 좋겠습니다.',
    'MB18');
insert into tblCSVoice (CSVSeq, CSVSubject, CSVContent, memberSeq)
    values ('CV'||CSVoice_seq.nextVal, '시스템개선',
    '운동영상을 쇼핑몰사이트에서 참고할 수 있는건 정말 좋은데 닭가슴살을 이용한 레시피등을 확인할 수 있으면 더 좋을것 같아요. ㅜㅜ 맛있게먹으면서 다이어트하고 싶어요.',
    'MB19');
insert into tblCSVoice (CSVSeq, CSVSubject, CSVContent, memberSeq)
    values ('CV'||CSVoice_seq.nextVal, '시스템개선',
    '신제품이 빨리빨리 쇼핑몰에 올라왔으면 좋겠습니다.!',
    'MB20');

-- 몸무게 (O) tblWeight
Insert into tblWeight (Weightseq,WEIGHT,WEIGHTDATE,MEMBERSEQ) values ('WG'||Weight_Seq.nextVal,70,'21-12-01','MB2');
Insert into tblWeight (Weightseq,WEIGHT,WEIGHTDATE,MEMBERSEQ) values ('WG'||Weight_Seq.nextVal,68,'21-12-02','MB2');
Insert into tblWeight (Weightseq,WEIGHT,WEIGHTDATE,MEMBERSEQ) values ('WG'||Weight_Seq.nextVal,66,'21-12-03','MB2');
Insert into tblWeight (Weightseq,WEIGHT,WEIGHTDATE,MEMBERSEQ) values ('WG'||Weight_Seq.nextVal,64,'21-12-04','MB2');
Insert into tblWeight (Weightseq,WEIGHT,WEIGHTDATE,MEMBERSEQ) values ('WG'||Weight_Seq.nextVal,64,'21-12-05','MB2');
Insert into tblWeight (Weightseq,WEIGHT,WEIGHTDATE,MEMBERSEQ) values ('WG'||Weight_Seq.nextVal,64,'21-12-06','MB2');
Insert into tblWeight (Weightseq,WEIGHT,WEIGHTDATE,MEMBERSEQ) values ('WG'||Weight_Seq.nextVal,64,'21-12-07','MB2');
Insert into tblWeight (Weightseq,WEIGHT,WEIGHTDATE,MEMBERSEQ) values ('WG'||Weight_Seq.nextVal,62,'21-12-08','MB2');
Insert into tblWeight (Weightseq,WEIGHT,WEIGHTDATE,MEMBERSEQ) values ('WG'||Weight_Seq.nextVal,64,'21-12-09','MB2');
Insert into tblWeight (Weightseq,WEIGHT,WEIGHTDATE,MEMBERSEQ) values ('WG'||Weight_Seq.nextVal,65,'21-12-10','MB2');
Insert into tblWeight (Weightseq,WEIGHT,WEIGHTDATE,MEMBERSEQ) values ('WG'||Weight_Seq.nextVal,68,'21-12-11','MB2');
Insert into tblWeight (Weightseq,WEIGHT,WEIGHTDATE,MEMBERSEQ) values ('WG'||Weight_Seq.nextVal,65,'21-12-12','MB2');
Insert into tblWeight (Weightseq,WEIGHT,WEIGHTDATE,MEMBERSEQ) values ('WG'||Weight_Seq.nextVal,65,'21-12-13','MB2');
Insert into tblWeight (Weightseq,WEIGHT,WEIGHTDATE,MEMBERSEQ) values ('WG'||Weight_Seq.nextVal,65,'21-12-14','MB2');
Insert into tblWeight (Weightseq,WEIGHT,WEIGHTDATE,MEMBERSEQ) values ('WG'||Weight_Seq.nextVal,65,'21-12-15','MB2');
Insert into tblWeight (Weightseq,WEIGHT,WEIGHTDATE,MEMBERSEQ) values ('WG'||Weight_Seq.nextVal,68,'21-12-16','MB2');
Insert into tblWeight (Weightseq,WEIGHT,WEIGHTDATE,MEMBERSEQ) values ('WG'||Weight_Seq.nextVal,68,'21-12-17','MB2');
Insert into tblWeight (Weightseq,WEIGHT,WEIGHTDATE,MEMBERSEQ) values ('WG'||Weight_Seq.nextVal,68,'21-12-18','MB2');
Insert into tblWeight (Weightseq,WEIGHT,WEIGHTDATE,MEMBERSEQ) values ('WG'||Weight_Seq.nextVal,66,'21-12-19','MB2');
Insert into tblWeight (Weightseq,WEIGHT,WEIGHTDATE,MEMBERSEQ) values ('WG'||Weight_Seq.nextVal,66,'21-12-20','MB2');
Insert into tblWeight (Weightseq,WEIGHT,WEIGHTDATE,MEMBERSEQ) values ('WG'||Weight_Seq.nextVal,66,'21-12-21','MB2');
Insert into tblWeight (Weightseq,WEIGHT,WEIGHTDATE,MEMBERSEQ) values ('WG'||Weight_Seq.nextVal,65,'21-12-22','MB2');
Insert into tblWeight (Weightseq,WEIGHT,WEIGHTDATE,MEMBERSEQ) values ('WG'||Weight_Seq.nextVal,64,'21-12-23','MB2');
Insert into tblWeight (Weightseq,WEIGHT,WEIGHTDATE,MEMBERSEQ) values ('WG'||Weight_Seq.nextVal,63,'21-12-24','MB2');
Insert into tblWeight (Weightseq,WEIGHT,WEIGHTDATE,MEMBERSEQ) values ('WG'||Weight_Seq.nextVal,61,'21-12-25','MB2');
Insert into tblWeight (Weightseq,WEIGHT,WEIGHTDATE,MEMBERSEQ) values ('WG'||Weight_Seq.nextVal,60,'21-12-26','MB2');
Insert into tblWeight (Weightseq,WEIGHT,WEIGHTDATE,MEMBERSEQ) values ('WG'||Weight_Seq.nextVal,58,'21-12-27','MB2');
Insert into tblWeight (Weightseq,WEIGHT,WEIGHTDATE,MEMBERSEQ) values ('WG'||Weight_Seq.nextVal,54,'21-12-28','MB2');
Insert into tblWeight (Weightseq,WEIGHT,WEIGHTDATE,MEMBERSEQ) values ('WG'||Weight_Seq.nextVal,53,'21-12-29','MB2');
Insert into tblWeight (Weightseq,WEIGHT,WEIGHTDATE,MEMBERSEQ) values ('WG'||Weight_Seq.nextVal,53,'21-12-30','MB2');
Insert into tblWeight (Weightseq,WEIGHT,WEIGHTDATE,MEMBERSEQ) values ('WG'||Weight_Seq.nextVal,53,'21-12-31','MB2');

-- 근육량 Muscle(O) tblmuscle
INSERT INTO tblMuscle (MUSCLESEQ, MUSCLE, MUSCLEDATE, MEMBERSEQ) VALUES ('MS'||Muscle_Seq.nextVal,30,'2021-12-01','MB2');
INSERT INTO tblMuscle (MUSCLESEQ, MUSCLE, MUSCLEDATE, MEMBERSEQ) VALUES ('MS'||Muscle_Seq.nextVal,29,'2021-12-02','MB2');
INSERT INTO tblMuscle (MUSCLESEQ, MUSCLE, MUSCLEDATE, MEMBERSEQ) VALUES ('MS'||Muscle_Seq.nextVal,28,'2021-12-03','MB2');
INSERT INTO tblMuscle (MUSCLESEQ, MUSCLE, MUSCLEDATE, MEMBERSEQ) VALUES ('MS'||Muscle_Seq.nextVal,28,'2021-12-04','MB2');
INSERT INTO tblMuscle (MUSCLESEQ, MUSCLE, MUSCLEDATE, MEMBERSEQ) VALUES ('MS'||Muscle_Seq.nextVal,28,'2021-12-05','MB2');
INSERT INTO tblMuscle (MUSCLESEQ, MUSCLE, MUSCLEDATE, MEMBERSEQ) VALUES ('MS'||Muscle_Seq.nextVal,28,'2021-12-06','MB2');
INSERT INTO tblMuscle (MUSCLESEQ, MUSCLE, MUSCLEDATE, MEMBERSEQ) VALUES ('MS'||Muscle_Seq.nextVal,28,'2021-12-07','MB2');
INSERT INTO tblMuscle (MUSCLESEQ, MUSCLE, MUSCLEDATE, MEMBERSEQ) VALUES ('MS'||Muscle_Seq.nextVal,27,'2021-12-08','MB2');
INSERT INTO tblMuscle (MUSCLESEQ, MUSCLE, MUSCLEDATE, MEMBERSEQ) VALUES ('MS'||Muscle_Seq.nextVal,27,'2021-12-09','MB2');
INSERT INTO tblMuscle (MUSCLESEQ, MUSCLE, MUSCLEDATE, MEMBERSEQ) VALUES ('MS'||Muscle_Seq.nextVal,28,'2021-12-10','MB2');
INSERT INTO tblMuscle (MUSCLESEQ, MUSCLE, MUSCLEDATE, MEMBERSEQ) VALUES ('MS'||Muscle_Seq.nextVal,28,'2021-12-11','MB2');
INSERT INTO tblMuscle (MUSCLESEQ, MUSCLE, MUSCLEDATE, MEMBERSEQ) VALUES ('MS'||Muscle_Seq.nextVal,25,'2021-12-12','MB2');
INSERT INTO tblMuscle (MUSCLESEQ, MUSCLE, MUSCLEDATE, MEMBERSEQ) VALUES ('MS'||Muscle_Seq.nextVal,25,'2021-12-13','MB2');
INSERT INTO tblMuscle (MUSCLESEQ, MUSCLE, MUSCLEDATE, MEMBERSEQ) VALUES ('MS'||Muscle_Seq.nextVal,25,'2021-12-14','MB2');
INSERT INTO tblMuscle (MUSCLESEQ, MUSCLE, MUSCLEDATE, MEMBERSEQ) VALUES ('MS'||Muscle_Seq.nextVal,25,'2021-12-15','MB2');
INSERT INTO tblMuscle (MUSCLESEQ, MUSCLE, MUSCLEDATE, MEMBERSEQ) VALUES ('MS'||Muscle_Seq.nextVal,27,'2021-12-16','MB2');
INSERT INTO tblMuscle (MUSCLESEQ, MUSCLE, MUSCLEDATE, MEMBERSEQ) VALUES ('MS'||Muscle_Seq.nextVal,27,'2021-12-17','MB2');
INSERT INTO tblMuscle (MUSCLESEQ, MUSCLE, MUSCLEDATE, MEMBERSEQ) VALUES ('MS'||Muscle_Seq.nextVal,27,'2021-12-18','MB2');
INSERT INTO tblMuscle (MUSCLESEQ, MUSCLE, MUSCLEDATE, MEMBERSEQ) VALUES ('MS'||Muscle_Seq.nextVal,26,'2021-12-19','MB2');
INSERT INTO tblMuscle (MUSCLESEQ, MUSCLE, MUSCLEDATE, MEMBERSEQ) VALUES ('MS'||Muscle_Seq.nextVal,26,'2021-12-20','MB2');
INSERT INTO tblMuscle (MUSCLESEQ, MUSCLE, MUSCLEDATE, MEMBERSEQ) VALUES ('MS'||Muscle_Seq.nextVal,26,'2021-12-21','MB2');
INSERT INTO tblMuscle (MUSCLESEQ, MUSCLE, MUSCLEDATE, MEMBERSEQ) VALUES ('MS'||Muscle_Seq.nextVal,25,'2021-12-22','MB2');
INSERT INTO tblMuscle (MUSCLESEQ, MUSCLE, MUSCLEDATE, MEMBERSEQ) VALUES ('MS'||Muscle_Seq.nextVal,24,'2021-12-23','MB2');
INSERT INTO tblMuscle (MUSCLESEQ, MUSCLE, MUSCLEDATE, MEMBERSEQ) VALUES ('MS'||Muscle_Seq.nextVal,23,'2021-12-24','MB2');
INSERT INTO tblMuscle (MUSCLESEQ, MUSCLE, MUSCLEDATE, MEMBERSEQ) VALUES ('MS'||Muscle_Seq.nextVal,22,'2021-12-25','MB2');
INSERT INTO tblMuscle (MUSCLESEQ, MUSCLE, MUSCLEDATE, MEMBERSEQ) VALUES ('MS'||Muscle_Seq.nextVal,21,'2021-12-26','MB2');
INSERT INTO tblMuscle (MUSCLESEQ, MUSCLE, MUSCLEDATE, MEMBERSEQ) VALUES ('MS'||Muscle_Seq.nextVal,20,'2021-12-27','MB2');
INSERT INTO tblMuscle (MUSCLESEQ, MUSCLE, MUSCLEDATE, MEMBERSEQ) VALUES ('MS'||Muscle_Seq.nextVal,19,'2021-12-28','MB2');
INSERT INTO tblMuscle (MUSCLESEQ, MUSCLE, MUSCLEDATE, MEMBERSEQ) VALUES ('MS'||Muscle_Seq.nextVal,19,'2021-12-29','MB2');
INSERT INTO tblMuscle (MUSCLESEQ, MUSCLE, MUSCLEDATE, MEMBERSEQ) VALUES ('MS'||Muscle_Seq.nextVal,19,'2021-12-30','MB2');
INSERT INTO tblMuscle (MUSCLESEQ, MUSCLE, MUSCLEDATE, MEMBERSEQ) VALUES ('MS'||Muscle_Seq.nextVal,18,'2021-12-31','MB2');

-- 체지방량Fat(O) tblFat
Insert into tblFat (fatSeq,fat,fatDate,memberSeq) values ('FA'||fat_Seq.nextVal,23,'2021-12-01','MB2');
Insert into tblFat (fatSeq,fat,fatDate,memberSeq) values ('FA'||fat_Seq.nextVal,23,'2021-12-02','MB2');
Insert into tblFat (fatSeq,fat,fatDate,memberSeq) values ('FA'||fat_Seq.nextVal,23,'2021-12-03','MB2');
Insert into tblFat (fatSeq,fat,fatDate,memberSeq) values ('FA'||fat_Seq.nextVal,22,'2021-12-04','MB2');
Insert into tblFat (fatSeq,fat,fatDate,memberSeq) values ('FA'||fat_Seq.nextVal,22,'2021-12-05','MB2');
Insert into tblFat (fatSeq,fat,fatDate,memberSeq) values ('FA'||fat_Seq.nextVal,22,'2021-12-06','MB2');
Insert into tblFat (fatSeq,fat,fatDate,memberSeq) values ('FA'||fat_Seq.nextVal,22,'2021-12-07','MB2');
Insert into tblFat (fatSeq,fat,fatDate,memberSeq) values ('FA'||fat_Seq.nextVal,21,'2021-12-08','MB2');
Insert into tblFat (fatSeq,fat,fatDate,memberSeq) values ('FA'||fat_Seq.nextVal,21,'2021-12-09','MB2');
Insert into tblFat (fatSeq,fat,fatDate,memberSeq) values ('FA'||fat_Seq.nextVal,21,'2021-12-10','MB2');
Insert into tblFat (fatSeq,fat,fatDate,memberSeq) values ('FA'||fat_Seq.nextVal,21,'2021-12-11','MB2');
Insert into tblFat (fatSeq,fat,fatDate,memberSeq) values ('FA'||fat_Seq.nextVal,20,'2021-12-12','MB2');
Insert into tblFat (fatSeq,fat,fatDate,memberSeq) values ('FA'||fat_Seq.nextVal,20,'2021-12-13','MB2');
Insert into tblFat (fatSeq,fat,fatDate,memberSeq) values ('FA'||fat_Seq.nextVal,20,'2021-12-14','MB2');
Insert into tblFat (fatSeq,fat,fatDate,memberSeq) values ('FA'||fat_Seq.nextVal,20,'2021-12-15','MB2');
Insert into tblFat (fatSeq,fat,fatDate,memberSeq) values ('FA'||fat_Seq.nextVal,19,'2021-12-16','MB2');
Insert into tblFat (fatSeq,fat,fatDate,memberSeq) values ('FA'||fat_Seq.nextVal,19,'2021-12-17','MB2');
Insert into tblFat (fatSeq,fat,fatDate,memberSeq) values ('FA'||fat_Seq.nextVal,19,'2021-12-18','MB2');
Insert into tblFat (fatSeq,fat,fatDate,memberSeq) values ('FA'||fat_Seq.nextVal,18,'2021-12-19','MB2');
Insert into tblFat (fatSeq,fat,fatDate,memberSeq) values ('FA'||fat_Seq.nextVal,18,'2021-12-20','MB2');
Insert into tblFat (fatSeq,fat,fatDate,memberSeq) values ('FA'||fat_Seq.nextVal,18,'2021-12-21','MB2');
Insert into tblFat (fatSeq,fat,fatDate,memberSeq) values ('FA'||fat_Seq.nextVal,17,'2021-12-22','MB2');
Insert into tblFat (fatSeq,fat,fatDate,memberSeq) values ('FA'||fat_Seq.nextVal,18,'2021-12-23','MB2');
Insert into tblFat (fatSeq,fat,fatDate,memberSeq) values ('FA'||fat_Seq.nextVal,19,'2021-12-24','MB2');
Insert into tblFat (fatSeq,fat,fatDate,memberSeq) values ('FA'||fat_Seq.nextVal,18,'2021-12-25','MB2');
Insert into tblFat (fatSeq,fat,fatDate,memberSeq) values ('FA'||fat_Seq.nextVal,17,'2021-12-26','MB2');
Insert into tblFat (fatSeq,fat,fatDate,memberSeq) values ('FA'||fat_Seq.nextVal,17,'2021-12-27','MB2');
Insert into tblFat (fatSeq,fat,fatDate,memberSeq) values ('FA'||fat_Seq.nextVal,16,'2021-12-28','MB2');
Insert into tblFat (fatSeq,fat,fatDate,memberSeq) values ('FA'||fat_Seq.nextVal,16,'2021-12-29','MB2');
Insert into tblFat (fatSeq,fat,fatDate,memberSeq) values ('FA'||fat_Seq.nextVal,16,'2021-12-30','MB2');
Insert into tblFat (fatSeq,fat,fatDate,memberSeq) values ('FA'||fat_Seq.nextVal,16,'2021-12-31','MB2');



-- 희망 스팩(O) tblWantspace
 insert into tblWantspec values ('WS'||wantSpec_seq.nextVal, 54, 16, 19, '2022-01-01', '벌크업', 'MB2');
 insert into tblWantspec values ('WS'||wantSpec_seq.nextVal, 55, 17, 20, '2022-01-02', '벌크업', 'MB2');
 insert into tblWantspec values ('WS'||wantSpec_seq.nextVal, 56, 17, 21, '2022-01-03', '벌크업', 'MB2');
 insert into tblWantspec values ('WS'||wantSpec_seq.nextVal, 57, 17, 22, '2022-01-04', '벌크업', 'MB2');
 insert into tblWantspec values ('WS'||wantSpec_seq.nextVal, 58, 17, 23, '2022-01-05', '벌크업', 'MB2');
 insert into tblWantspec values ('WS'||wantSpec_seq.nextVal, 59, 18, 24, '2022-01-06', '벌크업', 'MB2');
 insert into tblWantspec values ('WS'||wantSpec_seq.nextVal, 60, 18, 25, '2022-01-07', '벌크업', 'MB2');
 insert into tblWantspec values ('WS'||wantSpec_seq.nextVal, 61, 19, 26, '2022-01-08', '벌크업', 'MB2');
 insert into tblWantspec values ('WS'||wantSpec_seq.nextVal, 62, 19, 27, '2022-01-09', '벌크업', 'MB2');
 insert into tblWantspec values ('WS'||wantSpec_seq.nextVal, 63, 19, 28, '2022-01-10', '벌크업', 'MB2');
 insert into tblWantspec values ('WS'||wantSpec_seq.nextVal, 64, 19, 29, '2022-01-11', '벌크업', 'MB2');
 insert into tblWantspec values ('WS'||wantSpec_seq.nextVal, 65, 19, 30, '2022-01-12', '벌크업', 'MB2');
 insert into tblWantspec values ('WS'||wantSpec_seq.nextVal, 65, 19, 30, '2022-01-13', '벌크업', 'MB2');
 insert into tblWantspec values ('WS'||wantSpec_seq.nextVal, 67, 19, 31, '2022-01-14', '벌크업', 'MB2');
 insert into tblWantspec values ('WS'||wantSpec_seq.nextVal, 68, 19, 32, '2022-01-15', '벌크업', 'MB2');
 insert into tblWantspec values ('WS'||wantSpec_seq.nextVal, 69, 20, 32, '2022-01-16', '벌크업', 'MB2');
 insert into tblWantspec values ('WS'||wantSpec_seq.nextVal, 70, 20, 32, '2022-01-17', '벌크업', 'MB2');
 insert into tblWantspec values ('WS'||wantSpec_seq.nextVal, 77, 20, 32, '2022-01-18', '벌크업', 'MB2');

-- 주문서 Order(O)
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, 'CJ대한통운', '4878831887', 'phone', TO_DATE('2021-10-11 02:30:10', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB15'), 900, 'MB15', (SELECT postalCode FROM tblMember WHERE memberSeq='MB15'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '로젠택배', '06441277963', 'phone', TO_DATE('2021-05-13 15:14:38', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB6'), 2200, 'MB6', (SELECT postalCode FROM tblMember WHERE memberSeq='MB6'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, 'CJ대한통운', '42546021285', 'vbank', TO_DATE('2021-03-15 20:51:24', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB18'), 2500, 'MB18', (SELECT postalCode FROM tblMember WHERE memberSeq='MB18'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '로젠택배', '853555936286', 'trans', TO_DATE('2021-06-09 00:31:59', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB14'), 1800, 'MB14', (SELECT postalCode FROM tblMember WHERE memberSeq='MB14'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '로젠택배', '290677394364', 'card', TO_DATE('2021-07-22 18:11:32', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB15'), 0, 'MB15', (SELECT postalCode FROM tblMember WHERE memberSeq='MB15'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, 'CJ대한통운', '85155347407', 'vbank', TO_DATE('2021-08-14 12:20:53', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB12'), 1800, 'MB12', (SELECT postalCode FROM tblMember WHERE memberSeq='MB12'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '로젠택배', '705209531079', 'phone', TO_DATE('2021-02-15 18:49:12', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB1'), 0, 'MB1', (SELECT postalCode FROM tblMember WHERE memberSeq='MB1'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '우체국택배', '2988561114', 'vbank', TO_DATE('2021-04-24 00:30:33', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB8'), 2200, 'MB8', (SELECT postalCode FROM tblMember WHERE memberSeq='MB8'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, 'CJ대한통운', '374697540781', 'card', TO_DATE('2021-02-08 01:18:21', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB6'), 0, 'MB6', (SELECT postalCode FROM tblMember WHERE memberSeq='MB6'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, 'CJ대한통운', '2515002907', 'vbank', TO_DATE('2021-11-02 18:35:50', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB2'), 0, 'MB2', (SELECT postalCode FROM tblMember WHERE memberSeq='MB2'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '로젠택배', '71452261681', 'card', TO_DATE('2021-04-15 20:13:53', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB5'), 300, 'MB5', (SELECT postalCode FROM tblMember WHERE memberSeq='MB5'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, 'CJ대한통운', '03339418548', 'card', TO_DATE('2021-03-18 10:20:45', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB4'), 2400, 'MB4', (SELECT postalCode FROM tblMember WHERE memberSeq='MB4'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, 'CJ대한통운', '0788830882', 'phone', TO_DATE('2021-01-01 08:20:28', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB14'), 1500, 'MB14', (SELECT postalCode FROM tblMember WHERE memberSeq='MB14'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '우체국택배', '5074057639', 'trans', TO_DATE('2021-04-08 03:15:38', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB5'), 0, 'MB5', (SELECT postalCode FROM tblMember WHERE memberSeq='MB5'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, 'CJ대한통운', '38290440818', 'card', TO_DATE('2021-04-21 00:36:57', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB6'), 0, 'MB6', (SELECT postalCode FROM tblMember WHERE memberSeq='MB6'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '로젠택배', '68725858006', 'card', TO_DATE('2021-07-22 12:09:16', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB5'), 1700, 'MB5', (SELECT postalCode FROM tblMember WHERE memberSeq='MB5'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, 'CJ대한통운', '08279168053', 'trans', TO_DATE('2021-11-25 15:04:50', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB7'), 1800, 'MB7', (SELECT postalCode FROM tblMember WHERE memberSeq='MB7'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '우체국택배', '42730713115', 'vbank', TO_DATE('2021-02-12 19:54:41', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB14'), 0, 'MB14', (SELECT postalCode FROM tblMember WHERE memberSeq='MB14'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '우체국택배', '216782740131', 'phone', TO_DATE('2021-08-09 17:55:50', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB15'), 0, 'MB15', (SELECT postalCode FROM tblMember WHERE memberSeq='MB15'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, 'CJ대한통운', '5963717591', 'trans', TO_DATE('2021-11-22 16:55:40', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB15'), 0, 'MB15', (SELECT postalCode FROM tblMember WHERE memberSeq='MB15'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, 'CJ대한통운', '88068492950', 'trans', TO_DATE('2021-10-24 14:42:11', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB3'), 2800, 'MB3', (SELECT postalCode FROM tblMember WHERE memberSeq='MB3'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '로젠택배', '74425313492', 'card', TO_DATE('2021-04-15 12:34:50', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB13'), 2900, 'MB13', (SELECT postalCode FROM tblMember WHERE memberSeq='MB13'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, 'CJ대한통운', '56704696346', 'phone', TO_DATE('2021-08-18 05:15:35', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB17'), 2200, 'MB17', (SELECT postalCode FROM tblMember WHERE memberSeq='MB17'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, 'CJ대한통운', '9763263923', 'phone', TO_DATE('2021-05-21 13:25:38', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB10'), 300, 'MB10', (SELECT postalCode FROM tblMember WHERE memberSeq='MB10'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '우체국택배', '34779462378', 'card', TO_DATE('2021-01-14 16:21:53', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB12'), 0, 'MB12', (SELECT postalCode FROM tblMember WHERE memberSeq='MB12'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '로젠택배', '22593738689', 'card', TO_DATE('2021-04-28 01:21:23', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB17'), 2100, 'MB17', (SELECT postalCode FROM tblMember WHERE memberSeq='MB17'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '로젠택배', '69408763467', 'trans', TO_DATE('2021-06-03 20:03:27', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB10'), 1700, 'MB10', (SELECT postalCode FROM tblMember WHERE memberSeq='MB10'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '로젠택배', '99090486199', 'phone', TO_DATE('2021-05-06 17:44:39', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB7'), 400, 'MB7', (SELECT postalCode FROM tblMember WHERE memberSeq='MB7'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '우체국택배', '055424284392', 'card', TO_DATE('2021-10-03 00:46:05', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB9'), 0, 'MB9', (SELECT postalCode FROM tblMember WHERE memberSeq='MB9'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '로젠택배', '3309118912453', 'vbank', TO_DATE('2021-06-22 16:45:21', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB3'), 2600, 'MB3', (SELECT postalCode FROM tblMember WHERE memberSeq='MB3'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, 'CJ대한통운', '37541971781', 'vbank', TO_DATE('2021-08-01 22:22:52', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB5'), 3000, 'MB5', (SELECT postalCode FROM tblMember WHERE memberSeq='MB5'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, 'CJ대한통운', '9258189337524', 'vbank', TO_DATE('2021-08-06 18:20:09', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB7'), 0, 'MB7', (SELECT postalCode FROM tblMember WHERE memberSeq='MB7'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '우체국택배', '50463689093', 'vbank', TO_DATE('2021-08-20 12:47:22', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB3'), 0, 'MB3', (SELECT postalCode FROM tblMember WHERE memberSeq='MB3'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '로젠택배', '45010899515', 'card', TO_DATE('2021-10-17 10:47:02', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB17'), 0, 'MB17', (SELECT postalCode FROM tblMember WHERE memberSeq='MB17'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '우체국택배', '96484098649', 'vbank', TO_DATE('2021-04-09 02:07:04', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB14'), 1900, 'MB14', (SELECT postalCode FROM tblMember WHERE memberSeq='MB14'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '로젠택배', '480347413830', 'vbank', TO_DATE('2021-08-18 14:06:03', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB14'), 200, 'MB14', (SELECT postalCode FROM tblMember WHERE memberSeq='MB14'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '우체국택배', '77425894943', 'trans', TO_DATE('2021-08-21 13:23:44', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB3'), 0, 'MB3', (SELECT postalCode FROM tblMember WHERE memberSeq='MB3'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '우체국택배', '1432915568777', 'card', TO_DATE('2021-10-06 17:02:05', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB13'), 600, 'MB13', (SELECT postalCode FROM tblMember WHERE memberSeq='MB13'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '로젠택배', '87007109405', 'trans', TO_DATE('2021-10-16 00:51:20', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB3'), 0, 'MB3', (SELECT postalCode FROM tblMember WHERE memberSeq='MB3'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, 'CJ대한통운', '90463073390', 'trans', TO_DATE('2022-01-12  15:57:11', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB12'), 0, 'MB12', (SELECT postalCode FROM tblMember WHERE memberSeq='MB12'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '우체국택배', '0470840225', 'vbank', TO_DATE('2022-01-12  21:34:10', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB15'), 2900, 'MB15', (SELECT postalCode FROM tblMember WHERE memberSeq='MB15'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '로젠택배', '8871060754', 'phone', TO_DATE('2022-01-12  07:47:48', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB19'), 500, 'MB19', (SELECT postalCode FROM tblMember WHERE memberSeq='MB19'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '로젠택배', '33259733867', 'card', TO_DATE('2022-01-12  13:37:41', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB3'), 0, 'MB3', (SELECT postalCode FROM tblMember WHERE memberSeq='MB3'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '로젠택배', '8117225156', 'trans', TO_DATE('2022-01-12  06:57:05', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB18'), 0, 'MB18', (SELECT postalCode FROM tblMember WHERE memberSeq='MB18'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '우체국택배', '6748188482', 'card', TO_DATE('2022-01-12  23:14:18', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB15'), 0, 'MB15', (SELECT postalCode FROM tblMember WHERE memberSeq='MB15'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, 'CJ대한통운', '4531370239', 'card', TO_DATE('2022-01-12  14:36:49', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB12'), 0, 'MB12', (SELECT postalCode FROM tblMember WHERE memberSeq='MB12'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '로젠택배', '22317710133', 'phone', TO_DATE('2022-01-12  23:33:12', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB9'), 0, 'MB9', (SELECT postalCode FROM tblMember WHERE memberSeq='MB9'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '로젠택배', '03039541595', 'trans', TO_DATE('2022-01-12  11:25:40', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB19'), 2700, 'MB19', (SELECT postalCode FROM tblMember WHERE memberSeq='MB19'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '우체국택배', '22666235166', 'phone', TO_DATE('2022-01-12  19:18:59', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB8'), 0, 'MB8', (SELECT postalCode FROM tblMember WHERE memberSeq='MB8'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, 'CJ대한통운', '554460735825', 'trans', TO_DATE('2022-01-13 23:59:03', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB4'), 0, 'MB4', (SELECT postalCode FROM tblMember WHERE memberSeq='MB4'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, 'CJ대한통운', '89614435723', 'card', TO_DATE('2022-01-13 23:18:53', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB10'), 0, 'MB10', (SELECT postalCode FROM tblMember WHERE memberSeq='MB10'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, 'CJ대한통운', '636147168231', 'vbank', TO_DATE('2022-01-13 07:28:11', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB3'), 1600, 'MB3', (SELECT postalCode FROM tblMember WHERE memberSeq='MB3'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, 'CJ대한통운', '18519707063', 'trans', TO_DATE('2022-01-13 12:34:40', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB13'), 2900, 'MB13', (SELECT postalCode FROM tblMember WHERE memberSeq='MB13'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '우체국택배', '6829953512', 'vbank', TO_DATE('2022-01-13 15:58:58', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB15'), 0, 'MB15', (SELECT postalCode FROM tblMember WHERE memberSeq='MB15'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, 'CJ대한통운', '1096952127680', 'vbank', TO_DATE('2022-01-13 05:33:55', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB4'), 0, 'MB4', (SELECT postalCode FROM tblMember WHERE memberSeq='MB4'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '로젠택배', '31247902011', 'phone', TO_DATE('2022-01-13 02:42:05', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB19'), 0, 'MB19', (SELECT postalCode FROM tblMember WHERE memberSeq='MB19'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '우체국택배', '4502482613514', 'phone', TO_DATE('2022-01-13 08:33:21', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB7'), 1300, 'MB7', (SELECT postalCode FROM tblMember WHERE memberSeq='MB7'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, 'CJ대한통운', '57721126141', 'trans', TO_DATE('2022-01-13 00:06:34', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB1'), 1300, 'MB1', (SELECT postalCode FROM tblMember WHERE memberSeq='MB1'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, 'CJ대한통운', '1474404446649', 'vbank', TO_DATE('2022-01-13 20:24:21', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB15'), 0, 'MB15', (SELECT postalCode FROM tblMember WHERE memberSeq='MB15'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, 'CJ대한통운', '4817367689', 'trans', TO_DATE('2022-01-14 15:04:57', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB17'), 0, 'MB17', (SELECT postalCode FROM tblMember WHERE memberSeq='MB17'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '우체국택배', '2195914640', 'trans', TO_DATE('2022-01-14 19:29:20', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB10'), 0, 'MB10', (SELECT postalCode FROM tblMember WHERE memberSeq='MB10'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, 'CJ대한통운', '791602755262', 'card', TO_DATE('2022-01-14 09:04:12', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB5'), 2500, 'MB5', (SELECT postalCode FROM tblMember WHERE memberSeq='MB5'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '우체국택배', '82601667541', 'trans', TO_DATE('2022-01-14 09:16:17', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB13'), 0, 'MB13', (SELECT postalCode FROM tblMember WHERE memberSeq='MB13'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, 'CJ대한통운', '67665987405', 'phone', TO_DATE('2022-01-14 09:01:57', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB10'), 0, 'MB10', (SELECT postalCode FROM tblMember WHERE memberSeq='MB10'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, 'CJ대한통운', '23133072342', 'phone', TO_DATE('2022-01-14 07:07:48', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB12'), 500, 'MB12', (SELECT postalCode FROM tblMember WHERE memberSeq='MB12'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '로젠택배', '77703231540', 'phone', TO_DATE('2022-01-14 08:24:15', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB10'), 2900, 'MB10', (SELECT postalCode FROM tblMember WHERE memberSeq='MB10'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, 'CJ대한통운', '356764751099', 'card', TO_DATE('2022-01-14 17:53:03', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB19'), 0, 'MB19', (SELECT postalCode FROM tblMember WHERE memberSeq='MB19'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '로젠택배', '034957328923', 'card', TO_DATE('2022-01-14 21:20:28', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB16'), 1100, 'MB16', (SELECT postalCode FROM tblMember WHERE memberSeq='MB16'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, 'CJ대한통운', '2544082540', 'phone', TO_DATE('2022-01-14 01:42:17', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB3'), 0, 'MB3', (SELECT postalCode FROM tblMember WHERE memberSeq='MB3'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '우체국택배', '125598527754', 'trans', TO_DATE('2022-01-15 21:17:37', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB18'), 0, 'MB18', (SELECT postalCode FROM tblMember WHERE memberSeq='MB18'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '로젠택배', '24760846793', 'trans', TO_DATE('2022-01-15 12:07:12', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB5'), 1400, 'MB5', (SELECT postalCode FROM tblMember WHERE memberSeq='MB5'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, 'CJ대한통운', '004707869533', 'trans', TO_DATE('2022-01-15 21:22:12', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB7'), 0, 'MB7', (SELECT postalCode FROM tblMember WHERE memberSeq='MB7'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, 'CJ대한통운', '51282225768', 'vbank', TO_DATE('2022-01-15 18:44:32', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB13'), 300, 'MB13', (SELECT postalCode FROM tblMember WHERE memberSeq='MB13'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '로젠택배', '02084329230', 'trans', TO_DATE('2022-01-15 15:18:33', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB2'), 0, 'MB2', (SELECT postalCode FROM tblMember WHERE memberSeq='MB2'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '로젠택배', '1941635653', 'vbank', TO_DATE('2022-01-15 18:29:06', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB20'), 1700, 'MB20', (SELECT postalCode FROM tblMember WHERE memberSeq='MB20'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '로젠택배', '54117302723', 'card', TO_DATE('2022-01-15 11:19:41', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB4'), 800, 'MB4', (SELECT postalCode FROM tblMember WHERE memberSeq='MB4'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, 'CJ대한통운', '130047364230', 'trans', TO_DATE('2022-01-15 00:39:24', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB1'), 1600, 'MB1', (SELECT postalCode FROM tblMember WHERE memberSeq='MB1'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '우체국택배', '50420799270', 'vbank', TO_DATE('2022-01-15 07:40:26', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB3'), 1200, 'MB3', (SELECT postalCode FROM tblMember WHERE memberSeq='MB3'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, 'CJ대한통운', '8621569260', 'trans', TO_DATE('2022-01-15 02:58:00', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB9'), 0, 'MB9', (SELECT postalCode FROM tblMember WHERE memberSeq='MB9'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '우체국택배', '744343525662', 'phone', TO_DATE('2022-01-16 09:33:59', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB3'), 0, 'MB3', (SELECT postalCode FROM tblMember WHERE memberSeq='MB3'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, 'CJ대한통운', '93263337770', 'trans', TO_DATE('2022-01-16 12:11:31', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB3'), 2100, 'MB3', (SELECT postalCode FROM tblMember WHERE memberSeq='MB3'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '로젠택배', '855149689099', 'trans', TO_DATE('2022-01-16 12:33:47', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB3'), 1800, 'MB3', (SELECT postalCode FROM tblMember WHERE memberSeq='MB3'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, 'CJ대한통운', '5058507432', 'phone', TO_DATE('2022-01-16 05:52:26', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB11'), 0, 'MB11', (SELECT postalCode FROM tblMember WHERE memberSeq='MB11'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, 'CJ대한통운', '3174113504', 'trans', TO_DATE('2022-01-16 04:07:41', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB7'), 500, 'MB7', (SELECT postalCode FROM tblMember WHERE memberSeq='MB7'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '우체국택배', '080094984155', 'trans', TO_DATE('2022-01-16 02:59:12', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB20'), 0, 'MB20', (SELECT postalCode FROM tblMember WHERE memberSeq='MB20'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, 'CJ대한통운', '28165829455', 'phone', TO_DATE('2022-01-16 10:06:45', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB17'), 0, 'MB17', (SELECT postalCode FROM tblMember WHERE memberSeq='MB17'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '우체국택배', '45052184548', 'card', TO_DATE('2022-01-16 09:05:36', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB11'), 1600, 'MB11', (SELECT postalCode FROM tblMember WHERE memberSeq='MB11'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '로젠택배', '471311050814', 'card', TO_DATE('2022-01-16 16:34:53', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB11'), 0, 'MB11', (SELECT postalCode FROM tblMember WHERE memberSeq='MB11'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, 'CJ대한통운', '470777665720', 'phone', TO_DATE('2022-01-16 05:20:44', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB20'), 0, 'MB20', (SELECT postalCode FROM tblMember WHERE memberSeq='MB20'));
INSERT INTO tblOrder (orderSeq, courier, invoiceNum, paymentMethod, orderDate, orderAddress, useMileage, memberSeq, orderPostalCode) VALUES ('OD'||order_seq.nextVal, '우체국택배', '354253757010', 'vbank', TO_DATE('2022-01-16 16:36:47', 'YYYY-MM-DD hh24:mi:ss'), (SELECT address FROM tblMember WHERE memberSeq='MB2'), 1500, 'MB2', (SELECT postalCode FROM tblMember WHERE memberSeq='MB2'));

-- 필수 영양소 EssentialNT(O)
insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,8,22,2.2,'PD1');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,8,21,3,'PD2');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,9,22,3.1,'PD3');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,8,23,1.8,'PD4');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,8.63,17.45,4.12,'PD5');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,26,26,3.3,'PD6');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,14,23,4.4,'PD7');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,16,23,5,'PD8');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,21,23,6,'PD9');


insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,27,23,3.1,'PD10');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,12,19,4,'PD11');
insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,9,19,6.8,'PD12');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,4,27,4.7,'PD13');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,4,26,4.7,'PD14');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,4,22,0.9,'PD15');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,3,23,0.5,'PD16');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,3,24,0.9,'PD17');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,2,21,7,'PD18');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,1.13,27.6,1.65,'PD19');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,0,27.06,3.7,'PD20');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,51,16,4.6,'PD21');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,45,17,3.6,'PD22');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,46,18,6,'PD23');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,40,19,4.9,'PD24');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,50,18,2.9,'PD25');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,47,16,6,'PD26');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,41,14,8.8,'PD27');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,39,15.43,14,'PD28');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,56,16,4,'PD29');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,'43.5','14.3','7.8','PD30');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,47.9,12.4,8.6,'PD31');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,45.6,18.5,4.4,'PD32');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,48.7,14.5,8.2,'PD33');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,38,35,3.3,'PD34');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,48,30,4.8,'PD35');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,54,27,5,'PD36');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,55,31,6,'PD37');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,50,29,7,'PD38');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,46,23,7,'PD39');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,58,22,10,'PD40');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,0,0,0,'PD41');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,0,0,0,'PD42');


insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,0,0,0,'PD43');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,0,0,0,'PD44');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,0,0,0,'PD45');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,0,0,0,'PD46');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,0,0,0,'PD47');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,0,0,0,'PD48');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,0,0,0,'PD49');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,0,0,0,'PD50');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,0,0,0,'PD51');


insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,0,0,0,'PD52');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,0,0,0,'PD53');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,0,0,0,'PD54');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,0,0,0,'PD55');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,0,0,0,'PD56');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,0,0,0,'PD57');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,0,0,0,'PD58');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,0,0,0,'PD59');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,0,0,0,'PD60');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,7,23,1.6,'PD61');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,8,27,0.8,'PD62');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,46,44,2.4,'PD63');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,26,14,6,'PD64');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,29,12,6,'PD65');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,26,12,4.2,'PD66');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,26,11,5,'PD67');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,25,13,8,'PD68');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,1,1,0,'PD69');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,1,1,0,'PD70');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,11,27.5,2,'PD71');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,10,31,1.3,'PD72');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,15,22,6,'PD73');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,15,22,6,'PD74');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,15,22,6,'PD75');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,15,22,6,'PD76');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,7,25,1.5,'PD77');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,14,22,6,'PD78');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,4,24,2,'PD79');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,3,24,1,'PD80');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,4,5.5,0,'PD81');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,0,0,0,'PD82');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,5,0,0,'PD83');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,2,0,0,'PD84');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,0,0,0,'PD85');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,0,0,1,'PD86');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,0,0,0,'PD87');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,0,0,0,'PD88');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,0,0,0,'PD89');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,0,0,0,'PD90');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,0,2,0,'PD91');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,0,0,0,'PD92');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,0,0,0.5,'PD93');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,4.4,0,0,'PD94');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,0,0,0,'PD95');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,79.09,8.21,1.57,'PD96');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,0,0,0,'PD97');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,0,0,0,'PD98');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,0,0,0,'PD99');

insert into tblEssentialNT(ENNSeq,carbohydrate,protein,fat,productSeq)
	values ('EN' || EN_seq.nextVal,2.8,0.2,0,'PD100');

-- 상품 문의 QAProduct(O)
insert into tblQAProduct (QAPSeq, QASeq, ProductSeq) values ('QP'||QAProduct_Seq.nextVal, 'QA33', 'PD1');
insert into tblQAProduct (QAPSeq, QASeq, ProductSeq) values ('QP'||QAProduct_Seq.nextVal, 'QA34', 'PD2');
insert into tblQAProduct (QAPSeq, QASeq, ProductSeq) values ('QP'||QAProduct_Seq.nextVal, 'QA35', 'PD3');
insert into tblQAProduct (QAPSeq, QASeq, ProductSeq) values ('QP'||QAProduct_Seq.nextVal, 'QA36', 'PD4');
insert into tblQAProduct (QAPSeq, QASeq, ProductSeq) values ('QP'||QAProduct_Seq.nextVal, 'QA37', 'PD5');
insert into tblQAProduct (QAPSeq, QASeq, ProductSeq) values ('QP'||QAProduct_Seq.nextVal, 'QA38', 'PD6');
insert into tblQAProduct (QAPSeq, QASeq, ProductSeq) values ('QP'||QAProduct_Seq.nextVal, 'QA39', 'PD7');
insert into tblQAProduct (QAPSeq, QASeq, ProductSeq) values ('QP'||QAProduct_Seq.nextVal, 'QA40', 'PD8');
insert into tblQAProduct (QAPSeq, QASeq, ProductSeq) values ('QP'||QAProduct_Seq.nextVal, 'QA41', 'PD9');
insert into tblQAProduct (QAPSeq, QASeq, ProductSeq) values ('QP'||QAProduct_Seq.nextVal, 'QA42', 'PD10');

-- 장바구니 basket(O)

 insert into tblBasket values('BS'||basket_seq.nextVal, 'MB2', 'PD80', 1);
 insert into tblBasket values('BS'||basket_seq.nextVal, 'MB2', 'PD80', 2);
 insert into tblBasket values('BS'||basket_seq.nextVal, 'MB3', 'PD55', 3);
 insert into tblBasket values('BS'||basket_seq.nextVal, 'MB4', 'PD33', 2);
 insert into tblBasket values('BS'||basket_seq.nextVal, 'MB5', 'PD12', 2);
 insert into tblBasket values('BS'||basket_seq.nextVal, 'MB6', 'PD18', 2);
 insert into tblBasket values('BS'||basket_seq.nextVal, 'MB7', 'PD48', 1);
 insert into tblBasket values('BS'||basket_seq.nextVal, 'MB8', 'PD21', 2);
 insert into tblBasket values('BS'||basket_seq.nextVal, 'MB9', 'PD38', 1);
 insert into tblBasket values('BS'||basket_seq.nextVal, 'MB10', 'PD3', 1);
 insert into tblBasket values('BS'||basket_seq.nextVal, 'MB11', 'PD88', 1);
 insert into tblBasket values('BS'||basket_seq.nextVal, 'MB12', 'PD96', 3);
 insert into tblBasket values('BS'||basket_seq.nextVal, 'MB13', 'PD96', 3);
 insert into tblBasket values('BS'||basket_seq.nextVal, 'MB14', 'PD55', 1);
 insert into tblBasket values('BS'||basket_seq.nextVal, 'MB15', 'PD20', 1);
 insert into tblBasket values('BS'||basket_seq.nextVal, 'MB16', 'PD15', 1);
 insert into tblBasket values('BS'||basket_seq.nextVal, 'MB17', 'PD40', 3);
 insert into tblBasket values('BS'||basket_seq.nextVal, 'MB18', 'PD68', 3);
 insert into tblBasket values('BS'||basket_seq.nextVal, 'MB19', 'PD29', 3);
 insert into tblBasket values('BS'||basket_seq.nextVal, 'MB20', 'PD15', 1);
 insert into tblBasket values('BS'||basket_seq.nextVal, 'MB21', 'PD36', 2);
 insert into tblBasket values('BS'||basket_seq.nextVal, 'MB22', 'PD56', 1);
 insert into tblBasket values('BS'||basket_seq.nextVal, 'MB23', 'PD32', 1);
 insert into tblBasket values('BS'||basket_seq.nextVal, 'MB24', 'PD82', 2);
 insert into tblBasket values('BS'||basket_seq.nextVal, 'MB25', 'PD41', 3);
 insert into tblBasket values('BS'||basket_seq.nextVal, 'MB26', 'PD38', 1);
 insert into tblBasket values('BS'||basket_seq.nextVal, 'MB27', 'PD42', 1);
 insert into tblBasket values('BS'||basket_seq.nextVal, 'MB28', 'PD18', 1);
 insert into tblBasket values('BS'||basket_seq.nextVal, 'MB29', 'PD28', 3);
 insert into tblBasket values('BS'||basket_seq.nextVal, 'MB30', 'PD5', 3);
 insert into tblBasket values('BS'||basket_seq.nextVal, 'MB31', 'PD92', 1);
 insert into tblBasket values('BS'||basket_seq.nextVal, 'MB32', 'PD67', 3);
 insert into tblBasket values('BS'||basket_seq.nextVal, 'MB33', 'PD99', 1);
 insert into tblBasket values('BS'||basket_seq.nextVal, 'MB34', 'PD94', 1);
 insert into tblBasket values('BS'||basket_seq.nextVal, 'MB35', 'PD88', 2);
 
-- 기타 영양소 OtherNT(O)
insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD1');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD2');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD3');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD4');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD5');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD6');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD7');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD8');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD9');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD10');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD11');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD12');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD13');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD14');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD15');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD16');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD17');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD18');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD19');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD20');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD21');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD22');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD23');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD24');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD25');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD26');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD27');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD28');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD29');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD30');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD31');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD32');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD33');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD34');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD35');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD36');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD37');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD38');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD39');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD40');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD41');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD42');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD43');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD44');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD45');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD46');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD47');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD48');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD49');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD50');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD51');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD52');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD53');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD54');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD55');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD56');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD57');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD58');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD59');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD60');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD61');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD62');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD63');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD64');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD65');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD66');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD67');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD68');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','103mg','0mg','0mg','5.09mg','0mg','0mg','0mg','PD69');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','103mg','0mg','0mg','5.09mg','0mg','0mg','0mg','PD70');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD71');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD72');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD73');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD74');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD75');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD76');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD77');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD78');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','5.5mg','0mg','0mg','0mg','PD79');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','5.5mg','0mg','0mg','0mg','PD80');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD81');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD82');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD83');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD84');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD85');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD86');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD87');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD88');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','95mg','0mg','0mg','PD89');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','95mg','0mg','0mg','PD90');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD91');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','284mg','0mg','0mg','PD92');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','134mg','0mg','PD93');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD94');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD95');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD96');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','130mg','0mg','0mg','PD97');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD98');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','100mg','0mg','0mg','PD99');

insert into tblOtherNT(ONNSeq,fiber,caffeine,creatine,betaAlanine,bcaa,magnesium,milkthistle,dietaryfiber,productSeq) 
	values ('ON' || OtherNT_seq.nextVal,'0mg','0mg','0mg','0mg','0mg','0mg','0mg','0mg','PD100');

-- 상품 이미지 ProductURL(O)
insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD1','C:\Users\ebzm0\Desktop\이미지\닭가슴살\닭가슴살(1).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD3','C:\Users\ebzm0\Desktop\이미지\닭가슴살\닭가슴살(3).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD4','C:\Users\ebzm0\Desktop\이미지\닭가슴살\닭가슴살(4).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD5','C:\Users\ebzm0\Desktop\이미지\닭가슴살\닭가슴살(5).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD6','C:\Users\ebzm0\Desktop\이미지\닭가슴살\닭가슴살(6).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD7','C:\Users\ebzm0\Desktop\이미지\닭가슴살\닭가슴살(7).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD8','C:\Users\ebzm0\Desktop\이미지\닭가슴살\닭가슴살(8).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD9','C:\Users\ebzm0\Desktop\이미지\닭가슴살\닭가슴살(9).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD10','C:\Users\ebzm0\Desktop\이미지\닭가슴살\닭가슴살(10).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD11','C:\Users\ebzm0\Desktop\이미지\닭가슴살\닭가슴살(11).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD12','C:\Users\ebzm0\Desktop\이미지\닭가슴살\닭가슴살(12).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD13','C:\Users\ebzm0\Desktop\이미지\닭가슴살\닭가슴살(13).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD14','C:\Users\ebzm0\Desktop\이미지\닭가슴살\닭가슴살(14).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD15','C:\Users\ebzm0\Desktop\이미지\닭가슴살\닭가슴살(15).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD16','C:\Users\ebzm0\Desktop\이미지\닭가슴살\닭가슴살(16).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD17','C:\Users\ebzm0\Desktop\이미지\닭가슴살\닭가슴살(17).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD18','C:\Users\ebzm0\Desktop\이미지\닭가슴살\닭가슴살(18).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD19','C:\Users\ebzm0\Desktop\이미지\닭가슴살\닭가슴살(19).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD20','C:\Users\ebzm0\Desktop\이미지\닭가슴살\닭가슴살(20).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD21','C:\Users\ebzm0\Desktop\이미지\도시락\도시락(21).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD22','C:\Users\ebzm0\Desktop\이미지\도시락\도시락(22).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD23','C:\Users\ebzm0\Desktop\이미지\도시락\도시락(23).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD24','C:\Users\ebzm0\Desktop\이미지\도시락\도시락(24).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD25','C:\Users\ebzm0\Desktop\이미지\도시락\도시락(25).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD26','C:\Users\ebzm0\Desktop\이미지\도시락\도시락(26).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD27','C:\Users\ebzm0\Desktop\이미지\도시락\도시락(27).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD28','C:\Users\ebzm0\Desktop\이미지\도시락\도시락(28).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD29','C:\Users\ebzm0\Desktop\이미지\도시락\도시락(29).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD30','C:\Users\ebzm0\Desktop\이미지\도시락\도시락(30).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD31','C:\Users\ebzm0\Desktop\이미지\도시락\도시락(31).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD32','C:\Users\ebzm0\Desktop\이미지\도시락\도시락(32).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD33','C:\Users\ebzm0\Desktop\이미지\도시락\도시락(33).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD34','C:\Users\ebzm0\Desktop\이미지\도시락\도시락(34).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD35','C:\Users\ebzm0\Desktop\이미지\도시락\도시락(35).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD36','C:\Users\ebzm0\Desktop\이미지\도시락\도시락(36).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD37','C:\Users\ebzm0\Desktop\이미지\도시락\도시락(37).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD38','C:\Users\ebzm0\Desktop\이미지\도시락\도시락(38).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD39','C:\Users\ebzm0\Desktop\이미지\도시락\도시락(39).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD40','C:\Users\ebzm0\Desktop\이미지\도시락\도시락(40).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD41','C:\Users\ebzm0\Desktop\이미지\야채류\야채류(41).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD42','C:\Users\ebzm0\Desktop\이미지\야채류\야채류(42).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD43','C:\Users\ebzm0\Desktop\이미지\야채류\야채류(43).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD44','C:\Users\ebzm0\Desktop\이미지\야채류\야채류(44).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD45','C:\Users\ebzm0\Desktop\이미지\야채류\야채류(45).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD46','C:\Users\ebzm0\Desktop\이미지\야채류\야채류(46).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD47','C:\Users\ebzm0\Desktop\이미지\야채류\야채류(47).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD48','C:\Users\ebzm0\Desktop\이미지\야채류\야채류(48).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD49','C:\Users\ebzm0\Desktop\이미지\야채류\야채류(49).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD50','C:\Users\ebzm0\Desktop\이미지\야채류\야채류(50).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD51','C:\Users\ebzm0\Desktop\이미지\야채류\야채류(51).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD52','C:\Users\ebzm0\Desktop\이미지\야채류\야채류(52).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD53','C:\Users\ebzm0\Desktop\이미지\야채류\야채류(53).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD54','C:\Users\ebzm0\Desktop\이미지\야채류\야채류(54).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD55','C:\Users\ebzm0\Desktop\이미지\야채류\야채류(55).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD56','C:\Users\ebzm0\Desktop\이미지\야채류\야채류(56).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD57','C:\Users\ebzm0\Desktop\이미지\야채류\야채류(57).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD58','C:\Users\ebzm0\Desktop\이미지\야채류\야채류(58).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD59','C:\Users\ebzm0\Desktop\이미지\야채류\야채류(59).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD60','C:\Users\ebzm0\Desktop\이미지\야채류\야채류(60).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD61','C:\Users\ebzm0\Desktop\이미지\단백질보충제\단백질보충제(61).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD62','C:\Users\ebzm0\Desktop\이미지\단백질보충제\단백질보충제(62).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD63','C:\Users\ebzm0\Desktop\이미지\단백질보충제\단백질보충제(63).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD64','C:\Users\ebzm0\Desktop\이미지\단백질보충제\단백질보충제(64).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD65','C:\Users\ebzm0\Desktop\이미지\단백질보충제\단백질보충제(65).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD66','C:\Users\ebzm0\Desktop\이미지\단백질보충제\단백질보충제(66).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD67','C:\Users\ebzm0\Desktop\이미지\단백질보충제\단백질보충제(67).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD68','C:\Users\ebzm0\Desktop\이미지\단백질보충제\단백질보충제(68).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD69','C:\Users\ebzm0\Desktop\이미지\단백질보충제\단백질보충제(69).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD70','C:\Users\ebzm0\Desktop\이미지\단백질보충제\단백질보충제(70).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD71','C:\Users\ebzm0\Desktop\이미지\단백질보충제\단백질보충제(71).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD72','C:\Users\ebzm0\Desktop\이미지\단백질보충제\단백질보충제(72).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD73','C:\Users\ebzm0\Desktop\이미지\단백질보충제\단백질보충제(73).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD74','C:\Users\ebzm0\Desktop\이미지\단백질보충제\단백질보충제(74).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD75','C:\Users\ebzm0\Desktop\이미지\단백질보충제\단백질보충제(75).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD76','C:\Users\ebzm0\Desktop\이미지\단백질보충제\단백질보충제(76).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD77','C:\Users\ebzm0\Desktop\이미지\단백질보충제\단백질보충제(77).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD78','C:\Users\ebzm0\Desktop\이미지\단백질보충제\단백질보충제(78).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD79','C:\Users\ebzm0\Desktop\이미지\단백질보충제\단백질보충제(79).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD80','C:\Users\ebzm0\Desktop\이미지\단백질보충제\단백질보충제(80).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD81','C:\Users\ebzm0\Desktop\이미지\기타영양제\기타영양제(81).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD82','C:\Users\ebzm0\Desktop\이미지\기타영양제\기타영양제(82).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD83','C:\Users\ebzm0\Desktop\이미지\기타영양제\기타영양제(83).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD84','C:\Users\ebzm0\Desktop\이미지\기타영양제\기타영양제(84).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD85','C:\Users\ebzm0\Desktop\이미지\기타영양제\기타영양제(85).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD86','C:\Users\ebzm0\Desktop\이미지\기타영양제\기타영양제(86).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD87','C:\Users\ebzm0\Desktop\이미지\기타영양제\기타영양제(87).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD88','C:\Users\ebzm0\Desktop\이미지\기타영양제\기타영양제(88).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD89','C:\Users\ebzm0\Desktop\이미지\기타영양제\기타영양제(89).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD90','C:\Users\ebzm0\Desktop\이미지\기타영양제\기타영양제(90).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD91','C:\Users\ebzm0\Desktop\이미지\기타영양제\기타영양제(91).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD92','C:\Users\ebzm0\Desktop\이미지\기타영양제\기타영양제(92).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD93','C:\Users\ebzm0\Desktop\이미지\기타영양제\기타영양제(93).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD94','C:\Users\ebzm0\Desktop\이미지\기타영양제\기타영양제(94).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD95','C:\Users\ebzm0\Desktop\이미지\기타영양제\기타영양제(95).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD96','C:\Users\ebzm0\Desktop\이미지\기타영양제\기타영양제(96).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD97','C:\Users\ebzm0\Desktop\이미지\기타영양제\기타영양제(97).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD98','C:\Users\ebzm0\Desktop\이미지\기타영양제\기타영양제(98).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD99','C:\Users\ebzm0\Desktop\이미지\기타영양제\기타영양제(99).jpg');

insert into tblProductURL(productUrlSeq,productSeq,imgUrl) 
	values ('PU' || productUrl_seq.nextVal,'PD100','C:\Users\ebzm0\Desktop\이미지\기타영양제\기타영양제(100).jpg');




-- 배송 문의 QADelivery(O)
insert into tblQADelivery (QADSeq, QASeq, orderSeq) values ('QD'||QADelivery_Seq.nextVal, 'QA23', 'OD1');
insert into tblQADelivery (QADSeq, QASeq, orderSeq) values ('QD'||QADelivery_Seq.nextVal, 'QA24', 'OD2');
insert into tblQADelivery (QADSeq, QASeq, orderSeq) values ('QD'||QADelivery_Seq.nextVal, 'QA25', 'OD3');
insert into tblQADelivery (QADSeq, QASeq, orderSeq) values ('QD'||QADelivery_Seq.nextVal, 'QA26', 'OD4');
insert into tblQADelivery (QADSeq, QASeq, orderSeq) values ('QD'||QADelivery_Seq.nextVal, 'QA27', 'OD5');
insert into tblQADelivery (QADSeq, QASeq, orderSeq) values ('QD'||QADelivery_Seq.nextVal, 'QA28', 'OD6');
insert into tblQADelivery (QADSeq, QASeq, orderSeq) values ('QD'||QADelivery_Seq.nextVal, 'QA29', 'OD7');
insert into tblQADelivery (QADSeq, QASeq, orderSeq) values ('QD'||QADelivery_Seq.nextVal, 'QA30', 'OD8');
insert into tblQADelivery (QADSeq, QASeq, orderSeq) values ('QD'||QADelivery_Seq.nextVal, 'QA31', 'OD9');
insert into tblQADelivery (QADSeq, QASeq, orderSeq) values ('QD'||QADelivery_Seq.nextVal, 'QA32', 'OD10');

-- 주문서 개별 EachOrder(O)
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD8', 'OD1', '구매확정', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 50, 'PD78', 'OD2', '구매확정', 5);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD74', 'OD2', '구매확정', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 30, 'PD92', 'OD3', '구매확정', 3);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 30, 'PD19', 'OD3', '구매확정', 3);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 50, 'PD53', 'OD3', '구매확정', 5);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD51', 'OD4', '구매확정', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD82', 'OD4', '구매확정', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD52', 'OD4', '구매확정', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD83', 'OD5', '구매확정', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 30, 'PD19', 'OD6', '구매확정', 3);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 30, 'PD40', 'OD7', '구매확정', 3);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 30, 'PD42', 'OD8', '구매확정', 3);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 50, 'PD22', 'OD8', '구매확정', 5);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 30, 'PD90', 'OD8', '구매확정', 3);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 50, 'PD6', 'OD9', '구매확정', 5);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 50, 'PD64', 'OD9', '구매확정', 5);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 30, 'PD21', 'OD10', '구매확정', 3);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD22', 'OD11', '구매확정', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 30, 'PD1', 'OD11', '구매확정', 3);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 100, 'PD48', 'OD12', '구매확정', 7);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 30, 'PD78', 'OD13', '구매확정', 3);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD90', 'OD13', '구매확정', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD3', 'OD14', '구매확정', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 30, 'PD53', 'OD14', '구매확정', 3);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD48', 'OD15', '구매확정', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD36', 'OD16', '구매확정', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD33', 'OD16', '구매확정', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD49', 'OD17', '구매확정', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD84', 'OD18', '구매확정', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD57', 'OD19', '구매확정', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD94', 'OD20', '구매확정', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 50, 'PD40', 'OD20', '구매확정', 5);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD82', 'OD21', '구매확정', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD98', 'OD22', '구매확정', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD36', 'OD22', '구매확정', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 100, 'PD70', 'OD23', '구매확정', 7);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 30, 'PD98', 'OD23', '구매확정', 3);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD3', 'OD24', '구매확정', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 30, 'PD1', 'OD25', '구매확정', 3);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 30, 'PD50', 'OD26', '구매확정', 3);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 50, 'PD61', 'OD26', '구매확정', 5);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD62', 'OD27', '구매확정', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 30, 'PD93', 'OD28', '구매확정', 3);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 30, 'PD27', 'OD29', '구매확정', 3);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD47', 'OD29', '구매확정', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD30', 'OD30', '구매확정', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 50, 'PD47', 'OD31', '구매확정', 5);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD76', 'OD31', '구매확정', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 30, 'PD40', 'OD31', '구매확정', 3);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 30, 'PD46', 'OD32', '구매확정', 3);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 50, 'PD91', 'OD33', '구매확정', 5);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD98', 'OD33', '구매확정', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 50, 'PD84', 'OD34', '구매확정', 5);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 30, 'PD74', 'OD35', '구매확정', 3);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD7', 'OD35', '구매확정', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD66', 'OD36', '구매확정', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 30, 'PD86', 'OD37', '구매확정', 3);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 30, 'PD41', 'OD37', '구매확정', 3);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD83', 'OD38', '구매확정', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 50, 'PD16', 'OD38', '구매확정', 5);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD57', 'OD38', '구매확정', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 50, 'PD100', 'OD39', '구매확정', 5);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD7', 'OD40', '배송완료', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 100, 'PD56', 'OD40', '배송완료', 7);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD74', 'OD40', '배송완료', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 50, 'PD43', 'OD41', '배송완료', 5);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD76', 'OD41', '배송완료', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD17', 'OD42', '배송완료', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 50, 'PD20', 'OD42', '배송완료', 5);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 30, 'PD29', 'OD43', '배송완료', 3);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 50, 'PD26', 'OD43', '배송완료', 5);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 30, 'PD41', 'OD43', '배송완료', 3);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 50, 'PD91', 'OD44', '배송완료', 5);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 30, 'PD19', 'OD45', '배송완료', 3);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD91', 'OD46', '배송완료', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD27', 'OD46', '배송완료', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 30, 'PD78', 'OD47', '배송완료', 3);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD48', 'OD48', '배송완료', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 50, 'PD28', 'OD49', '배송완료', 5);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD95', 'OD50', '배송중', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD10', 'OD51', '배송중', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 30, 'PD32', 'OD52', '배송중', 3);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD85', 'OD53', '배송중', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD36', 'OD53', '배송중', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD38', 'OD54', '배송중', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD59', 'OD54', '배송중', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD31', 'OD55', '배송중', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD59', 'OD55', '배송중', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD99', 'OD55', '배송중', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 50, 'PD61', 'OD56', '배송중', 5);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 30, 'PD42', 'OD56', '배송중', 3);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD27', 'OD57', '배송중', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD25', 'OD57', '배송중', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 30, 'PD70', 'OD58', '배송중', 3);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD43', 'OD59', '배송중', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 50, 'PD62', 'OD59', '배송중', 5);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 100, 'PD79', 'OD60', '출고준비중', 7);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 30, 'PD87', 'OD60', '출고준비중', 3);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 30, 'PD58', 'OD61', '출고준비중', 3);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD19', 'OD62', '출고준비중', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD91', 'OD62', '출고준비중', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD56', 'OD63', '출고준비중', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 30, 'PD78', 'OD63', '출고준비중', 3);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 30, 'PD34', 'OD64', '출고준비중', 3);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD83', 'OD64', '출고준비중', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 30, 'PD53', 'OD64', '출고준비중', 3);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD26', 'OD65', '출고준비중', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 50, 'PD30', 'OD65', '출고준비중', 5);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD77', 'OD66', '출고준비중', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 50, 'PD26', 'OD66', '출고준비중', 5);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 30, 'PD19', 'OD66', '출고준비중', 3);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD11', 'OD67', '출고준비중', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 50, 'PD6', 'OD68', '출고준비중', 5);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 50, 'PD12', 'OD68', '출고준비중', 5);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 50, 'PD87', 'OD68', '출고준비중', 5);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 30, 'PD74', 'OD69', '출고준비중', 3);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD41', 'OD69', '출고준비중', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD7', 'OD70', '상품준비중', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 30, 'PD90', 'OD70', '상품준비중', 3);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD78', 'OD70', '상품준비중', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD68', 'OD71', '상품준비중', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD96', 'OD72', '상품준비중', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD9', 'OD72', '상품준비중', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 30, 'PD62', 'OD73', '상품준비중', 3);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD16', 'OD73', '상품준비중', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 30, 'PD47', 'OD74', '상품준비중', 3);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 100, 'PD93', 'OD74', '상품준비중', 7);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 100, 'PD97', 'OD75', '상품준비중', 7);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 50, 'PD72', 'OD75', '상품준비중', 5);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 30, 'PD39', 'OD76', '상품준비중', 3);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 100, 'PD65', 'OD76', '상품준비중', 7);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD13', 'OD77', '상품준비중', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 100, 'PD55', 'OD77', '상품준비중', 7);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD87', 'OD78', '상품준비중', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD78', 'OD79', '상품준비중', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD28', 'OD79', '상품준비중', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 100, 'PD80', 'OD79', '상품준비중', 7);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD9', 'OD80', '결제완료', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD32', 'OD80', '결제완료', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD86', 'OD80', '결제완료', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 30, 'PD30', 'OD81', '결제완료', 3);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 30, 'PD9', 'OD81', '결제완료', 3);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 30, 'PD82', 'OD81', '결제완료', 3);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 30, 'PD72', 'OD82', '결제완료', 3);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 30, 'PD22', 'OD82', '결제완료', 3);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD61', 'OD83', '결제완료', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 30, 'PD31', 'OD84', '결제완료', 3);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 50, 'PD56', 'OD85', '결제완료', 5);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD66', 'OD85', '결제완료', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 30, 'PD9', 'OD85', '결제완료', 3);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD99', 'OD86', '결제완료', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 50, 'PD1', 'OD86', '결제완료', 5);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD100', 'OD86', '결제완료', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 30, 'PD57', 'OD87', '결제완료', 3);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD25', 'OD87', '결제완료', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD37', 'OD88', '결제완료', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 1, 'PD20', 'OD88', '결제완료', 0);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 30, 'PD14', 'OD88', '결제완료', 3);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 100, 'PD12', 'OD89', '결제완료', 7);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 30, 'PD31', 'OD89', '결제완료', 3);
INSERT INTO tblEachOrder (eachOrderSeq, stock, productSeq, orderSeq, process, discountRate) VALUES ('EO'||eachOrder_seq.nextVal, 30, 'PD92', 'OD90', '결제완료', 3);

-- 리뷰 Review
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '역시 믿고 구매합니다. 제 건강을 위해 정말 좋은 선택을 한 것 같아요!', 4.8, 'EO1',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO1')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '항상 떨어질 때 쯤 구매하는 제품이에요..! 제발 단종되지 않길 ㅠㅠ..', 3.8, 'EO2',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO2')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '항상 떨어질 때 쯤 구매하는 제품이에요..! 제발 단종되지 않길 ㅠㅠ..', 4.4, 'EO3',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO3')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '정말 좋은 제품인데 이번에는 별로 좋지못한 제품이 배송됐네요 ㅠ 귀찮아서 그냥 먹습니다..', 3.4, 'EO4',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO4')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '오늘도 내일도 먹는 제품!! 많이 먹고 많이 득근할게요~!', 4.9, 'EO5',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO5')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '오늘도 내일도 먹는 제품!! 많이 먹고 많이 득근할게요~!', 4.2, 'EO6',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO6')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '역시 믿고 구매합니다. 제 건강을 위해 정말 좋은 선택을 한 것 같아요!', 4.6, 'EO7',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO7')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '오늘도 내일도 먹는 제품!! 많이 먹고 많이 득근할게요~!', 4.4, 'EO8',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO8')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '오늘도 내일도 먹는 제품!! 많이 먹고 많이 득근할게요~!', 4.5, 'EO9',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO9')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '오늘도 내일도 먹는 제품!! 많이 먹고 많이 득근할게요~!', 4.0, 'EO10',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO10')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '이거 없으면 못 살 정도로 저에게 필요합니다.. 항상 배송 꼼꼼히 빠르게 오고 상태도 좋네요^^', 4.9, 'EO11',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO11')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '오늘도 내일도 먹는 제품!! 많이 먹고 많이 득근할게요~!', 3.1, 'EO12',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO12')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '항상 떨어질 때 쯤 구매하는 제품이에요..! 제발 단종되지 않길 ㅠㅠ..', 4.4, 'EO13',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO13')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '정말 좋은 제품인데 이번에는 별로 좋지못한 제품이 배송됐네요 ㅠ 귀찮아서 그냥 먹습니다..', 4.1, 'EO14',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO14')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '항상 떨어질 때 쯤 구매하는 제품이에요..! 제발 단종되지 않길 ㅠㅠ..', 4.4, 'EO15',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO15')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '이거 없으면 못 살 정도로 저에게 필요합니다.. 항상 배송 꼼꼼히 빠르게 오고 상태도 좋네요^^', 3.5, 'EO16',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO16')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '정말 좋은 제품인데 이번에는 별로 좋지못한 제품이 배송됐네요 ㅠ 귀찮아서 그냥 먹습니다..', 4.2, 'EO17',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO17')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '오늘도 내일도 먹는 제품!! 많이 먹고 많이 득근할게요~!', 3.8, 'EO18',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO18')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '정말 좋은 제품인데 이번에는 별로 좋지못한 제품이 배송됐네요 ㅠ 귀찮아서 그냥 먹습니다..', 4.0, 'EO19',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO19')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '항상 떨어질 때 쯤 구매하는 제품이에요..! 제발 단종되지 않길 ㅠㅠ..', 3.6, 'EO20',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO20')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '항상 떨어질 때 쯤 구매하는 제품이에요..! 제발 단종되지 않길 ㅠㅠ..', 3.3, 'EO21',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO21')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '정말 좋은 제품인데 이번에는 별로 좋지못한 제품이 배송됐네요 ㅠ 귀찮아서 그냥 먹습니다..', 4.2, 'EO22',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO22')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '이거 없으면 못 살 정도로 저에게 필요합니다.. 항상 배송 꼼꼼히 빠르게 오고 상태도 좋네요^^', 4.8, 'EO23',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO23')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '정말 좋은 제품인데 이번에는 별로 좋지못한 제품이 배송됐네요 ㅠ 귀찮아서 그냥 먹습니다..', 4.3, 'EO24',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO24')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '정말 좋은 제품인데 이번에는 별로 좋지못한 제품이 배송됐네요 ㅠ 귀찮아서 그냥 먹습니다..', 5.0, 'EO25',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO25')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '항상 떨어질 때 쯤 구매하는 제품이에요..! 제발 단종되지 않길 ㅠㅠ..', 3.1, 'EO26',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO26')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '오늘도 내일도 먹는 제품!! 많이 먹고 많이 득근할게요~!', 3.4, 'EO27',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO27')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '이거 없으면 못 살 정도로 저에게 필요합니다.. 항상 배송 꼼꼼히 빠르게 오고 상태도 좋네요^^', 5.1, 'EO28',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO28')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '역시 믿고 구매합니다. 제 건강을 위해 정말 좋은 선택을 한 것 같아요!', 3.3, 'EO29',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO29')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '오늘도 내일도 먹는 제품!! 많이 먹고 많이 득근할게요~!', 4.7, 'EO30',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO30')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '오늘도 내일도 먹는 제품!! 많이 먹고 많이 득근할게요~!', 4.5, 'EO31',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO31')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '정말 좋은 제품인데 이번에는 별로 좋지못한 제품이 배송됐네요 ㅠ 귀찮아서 그냥 먹습니다..', 4.5, 'EO32',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO32')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '역시 믿고 구매합니다. 제 건강을 위해 정말 좋은 선택을 한 것 같아요!', 4.4, 'EO33',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO33')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '역시 믿고 구매합니다. 제 건강을 위해 정말 좋은 선택을 한 것 같아요!', 4.1, 'EO34',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO34')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '항상 떨어질 때 쯤 구매하는 제품이에요..! 제발 단종되지 않길 ㅠㅠ..', 3.2, 'EO35',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO35')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '이거 없으면 못 살 정도로 저에게 필요합니다.. 항상 배송 꼼꼼히 빠르게 오고 상태도 좋네요^^', 3.6, 'EO36',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO36')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '이거 없으면 못 살 정도로 저에게 필요합니다.. 항상 배송 꼼꼼히 빠르게 오고 상태도 좋네요^^', 5.1, 'EO37',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO37')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '항상 떨어질 때 쯤 구매하는 제품이에요..! 제발 단종되지 않길 ㅠㅠ..', 5.0, 'EO38',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO38')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '역시 믿고 구매합니다. 제 건강을 위해 정말 좋은 선택을 한 것 같아요!', 4.1, 'EO39',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO39')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '항상 떨어질 때 쯤 구매하는 제품이에요..! 제발 단종되지 않길 ㅠㅠ..', 5.0, 'EO40',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO40')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '역시 믿고 구매합니다. 제 건강을 위해 정말 좋은 선택을 한 것 같아요!', 3.4, 'EO41',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO41')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '역시 믿고 구매합니다. 제 건강을 위해 정말 좋은 선택을 한 것 같아요!', 4.5, 'EO42',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO42')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '역시 믿고 구매합니다. 제 건강을 위해 정말 좋은 선택을 한 것 같아요!', 3.6, 'EO43',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO43')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '오늘도 내일도 먹는 제품!! 많이 먹고 많이 득근할게요~!', 4.7, 'EO44',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO44')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '정말 좋은 제품인데 이번에는 별로 좋지못한 제품이 배송됐네요 ㅠ 귀찮아서 그냥 먹습니다..', 3.2, 'EO45',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO45')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '항상 떨어질 때 쯤 구매하는 제품이에요..! 제발 단종되지 않길 ㅠㅠ..', 4.6, 'EO46',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO46')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '항상 떨어질 때 쯤 구매하는 제품이에요..! 제발 단종되지 않길 ㅠㅠ..', 3.9, 'EO47',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO47')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '역시 믿고 구매합니다. 제 건강을 위해 정말 좋은 선택을 한 것 같아요!', 3.7, 'EO48',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO48')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '정말 좋은 제품인데 이번에는 별로 좋지못한 제품이 배송됐네요 ㅠ 귀찮아서 그냥 먹습니다..', 5.0, 'EO49',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO49')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '역시 믿고 구매합니다. 제 건강을 위해 정말 좋은 선택을 한 것 같아요!', 4.6, 'EO50',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO50')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '역시 믿고 구매합니다. 제 건강을 위해 정말 좋은 선택을 한 것 같아요!', 3.5, 'EO51',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO51')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '항상 떨어질 때 쯤 구매하는 제품이에요..! 제발 단종되지 않길 ㅠㅠ..', 4.5, 'EO52',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO52')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '오늘도 내일도 먹는 제품!! 많이 먹고 많이 득근할게요~!', 3.1, 'EO53',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO53')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '오늘도 내일도 먹는 제품!! 많이 먹고 많이 득근할게요~!', 3.2, 'EO54',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO54')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '이거 없으면 못 살 정도로 저에게 필요합니다.. 항상 배송 꼼꼼히 빠르게 오고 상태도 좋네요^^', 3.3, 'EO55',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO55')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '정말 좋은 제품인데 이번에는 별로 좋지못한 제품이 배송됐네요 ㅠ 귀찮아서 그냥 먹습니다..', 3.5, 'EO56',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO56')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '오늘도 내일도 먹는 제품!! 많이 먹고 많이 득근할게요~!', 4.5, 'EO57',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO57')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '항상 떨어질 때 쯤 구매하는 제품이에요..! 제발 단종되지 않길 ㅠㅠ..', 4.2, 'EO58',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO58')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '정말 좋은 제품인데 이번에는 별로 좋지못한 제품이 배송됐네요 ㅠ 귀찮아서 그냥 먹습니다..', 3.8, 'EO59',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO59')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '오늘도 내일도 먹는 제품!! 많이 먹고 많이 득근할게요~!', 3.5, 'EO60',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO60')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '오늘도 내일도 먹는 제품!! 많이 먹고 많이 득근할게요~!', 3.9, 'EO61',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO61')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '이거 없으면 못 살 정도로 저에게 필요합니다.. 항상 배송 꼼꼼히 빠르게 오고 상태도 좋네요^^', 4.1, 'EO62',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO62')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '이거 없으면 못 살 정도로 저에게 필요합니다.. 항상 배송 꼼꼼히 빠르게 오고 상태도 좋네요^^', 4.1, 'EO63',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO63')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '항상 떨어질 때 쯤 구매하는 제품이에요..! 제발 단종되지 않길 ㅠㅠ..', 3.3, 'EO64',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO64')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '정말 좋은 제품인데 이번에는 별로 좋지못한 제품이 배송됐네요 ㅠ 귀찮아서 그냥 먹습니다..', 3.4, 'EO65',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO65')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '이거 없으면 못 살 정도로 저에게 필요합니다.. 항상 배송 꼼꼼히 빠르게 오고 상태도 좋네요^^', 3.2, 'EO66',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO66')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '이거 없으면 못 살 정도로 저에게 필요합니다.. 항상 배송 꼼꼼히 빠르게 오고 상태도 좋네요^^', 3.5, 'EO67',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO67')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '정말 좋은 제품인데 이번에는 별로 좋지못한 제품이 배송됐네요 ㅠ 귀찮아서 그냥 먹습니다..', 5.1, 'EO68',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO68')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '항상 떨어질 때 쯤 구매하는 제품이에요..! 제발 단종되지 않길 ㅠㅠ..', 4.7, 'EO69',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO69')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '역시 믿고 구매합니다. 제 건강을 위해 정말 좋은 선택을 한 것 같아요!', 4.9, 'EO70',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO70')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '역시 믿고 구매합니다. 제 건강을 위해 정말 좋은 선택을 한 것 같아요!', 4.5, 'EO71',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO71')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '항상 떨어질 때 쯤 구매하는 제품이에요..! 제발 단종되지 않길 ㅠㅠ..', 3.8, 'EO72',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO72')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '오늘도 내일도 먹는 제품!! 많이 먹고 많이 득근할게요~!', 3.5, 'EO73',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO73')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '이거 없으면 못 살 정도로 저에게 필요합니다.. 항상 배송 꼼꼼히 빠르게 오고 상태도 좋네요^^', 3.9, 'EO74',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO74')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '항상 떨어질 때 쯤 구매하는 제품이에요..! 제발 단종되지 않길 ㅠㅠ..', 3.4, 'EO75',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO75')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '항상 떨어질 때 쯤 구매하는 제품이에요..! 제발 단종되지 않길 ㅠㅠ..', 4.8, 'EO76',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO76')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '오늘도 내일도 먹는 제품!! 많이 먹고 많이 득근할게요~!', 3.3, 'EO77',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO77')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '역시 믿고 구매합니다. 제 건강을 위해 정말 좋은 선택을 한 것 같아요!', 4.0, 'EO78',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO78')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '정말 좋은 제품인데 이번에는 별로 좋지못한 제품이 배송됐네요 ㅠ 귀찮아서 그냥 먹습니다..', 4.9, 'EO79',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO79')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '이거 없으면 못 살 정도로 저에게 필요합니다.. 항상 배송 꼼꼼히 빠르게 오고 상태도 좋네요^^', 3.5, 'EO80',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO80')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '역시 믿고 구매합니다. 제 건강을 위해 정말 좋은 선택을 한 것 같아요!', 4.4, 'EO81',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO81')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '항상 떨어질 때 쯤 구매하는 제품이에요..! 제발 단종되지 않길 ㅠㅠ..', 5.1, 'EO82',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO82')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '역시 믿고 구매합니다. 제 건강을 위해 정말 좋은 선택을 한 것 같아요!', 4.0, 'EO83',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO83')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '이거 없으면 못 살 정도로 저에게 필요합니다.. 항상 배송 꼼꼼히 빠르게 오고 상태도 좋네요^^', 3.4, 'EO84',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO84')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '오늘도 내일도 먹는 제품!! 많이 먹고 많이 득근할게요~!', 4.6, 'EO85',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO85')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '이거 없으면 못 살 정도로 저에게 필요합니다.. 항상 배송 꼼꼼히 빠르게 오고 상태도 좋네요^^', 4.7, 'EO86',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO86')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '항상 떨어질 때 쯤 구매하는 제품이에요..! 제발 단종되지 않길 ㅠㅠ..', 3.9, 'EO87',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO87')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '오늘도 내일도 먹는 제품!! 많이 먹고 많이 득근할게요~!', 4.3, 'EO88',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO88')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '이거 없으면 못 살 정도로 저에게 필요합니다.. 항상 배송 꼼꼼히 빠르게 오고 상태도 좋네요^^', 4.7, 'EO89',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO89')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '오늘도 내일도 먹는 제품!! 많이 먹고 많이 득근할게요~!', 3.2, 'EO90',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO90')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '이거 없으면 못 살 정도로 저에게 필요합니다.. 항상 배송 꼼꼼히 빠르게 오고 상태도 좋네요^^', 5.1, 'EO91',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO91')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '항상 떨어질 때 쯤 구매하는 제품이에요..! 제발 단종되지 않길 ㅠㅠ..', 3.5, 'EO92',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO92')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '정말 좋은 제품인데 이번에는 별로 좋지못한 제품이 배송됐네요 ㅠ 귀찮아서 그냥 먹습니다..', 4.8, 'EO93',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO93')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '오늘도 내일도 먹는 제품!! 많이 먹고 많이 득근할게요~!', 4.2, 'EO94',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO94')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '항상 떨어질 때 쯤 구매하는 제품이에요..! 제발 단종되지 않길 ㅠㅠ..', 3.6, 'EO95',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO95')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '항상 떨어질 때 쯤 구매하는 제품이에요..! 제발 단종되지 않길 ㅠㅠ..', 3.4, 'EO96',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO96')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '항상 떨어질 때 쯤 구매하는 제품이에요..! 제발 단종되지 않길 ㅠㅠ..', 4.7, 'EO97',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO97')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '이거 없으면 못 살 정도로 저에게 필요합니다.. 항상 배송 꼼꼼히 빠르게 오고 상태도 좋네요^^', 3.5, 'EO98',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO98')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '항상 떨어질 때 쯤 구매하는 제품이에요..! 제발 단종되지 않길 ㅠㅠ..', 4.4, 'EO99',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO99')));
INSERT INTO tblReview (reviewSeq, reviewContent, reviewPoint, eachOrderSeq, reviewDate) VALUES ('RV'||review_seq.nextVal, '정말 좋은 제품인데 이번에는 별로 좋지못한 제품이 배송됐네요 ㅠ 귀찮아서 그냥 먹습니다..', 4.9, 'EO100',(SELECT orderDate FROM tblOrder WHERE orderSeq=(SELECT orderSeq FROM tblEachOrder WHERE eachOrderSeq='EO100')));

-- 상품 회수 refund
INSERT INTO tblRefund (refundSeq, refundDate, refundRequest, eachOrderSeq, refundCheck) VALUES ('RF'||refund_seq.nextVal, TO_DATE('2022-01-12  23:40:13', 'YYYY-MM-DD hh24:mi:ss'), '제품에 하자가 있네요; 환불 부탁드립니다', 'EO40', '회수완료');
INSERT INTO tblRefund (refundSeq, refundDate, refundRequest, eachOrderSeq, refundCheck) VALUES ('RF'||refund_seq.nextVal, TO_DATE('2022-01-12  23:10:13', 'YYYY-MM-DD hh24:mi:ss'), '포장 불량으로 제품이 파손됐네요..', 'EO41', '회수완료');
INSERT INTO tblRefund (refundSeq, refundDate, refundRequest, eachOrderSeq, refundCheck) VALUES ('RF'||refund_seq.nextVal, TO_DATE('2022-01-12  23:39:18', 'YYYY-MM-DD hh24:mi:ss'), '..아니 이거 제품 상태가 좀 이상하네요 ㅠ 확인좀 부탁드려요', 'EO42', '회수완료');
INSERT INTO tblRefund (refundSeq, refundDate, refundRequest, eachOrderSeq, refundCheck) VALUES ('RF'||refund_seq.nextVal, TO_DATE('2022-01-12  23:36:28', 'YYYY-MM-DD hh24:mi:ss'), '하 반품신청합니다 ㅠ 제품 상태가 불량이네요', 'EO43', '회수완료');
INSERT INTO tblRefund (refundSeq, refundDate, refundRequest, eachOrderSeq, refundCheck) VALUES ('RF'||refund_seq.nextVal, TO_DATE('2022-01-12  23:12:22', 'YYYY-MM-DD hh24:mi:ss'), '포장 상태가 참.. 이런식으로 판매하시면 금방 망합니다.', 'EO44', '회수완료');
INSERT INTO tblRefund (refundSeq, refundDate, refundRequest, eachOrderSeq, refundCheck) VALUES ('RF'||refund_seq.nextVal, TO_DATE('2022-01-12  23:56:06', 'YYYY-MM-DD hh24:mi:ss'), '배송이 몇일째 안오는건지.. 그냥 환불해주세요', 'EO45', '회수완료');
INSERT INTO tblRefund (refundSeq, refundDate, refundRequest, eachOrderSeq, refundCheck) VALUES ('RF'||refund_seq.nextVal, TO_DATE('2022-01-12  23:22:45', 'YYYY-MM-DD hh24:mi:ss'), '환불좀요.. 이상태면 못먹어요', 'EO46', '회수완료');
INSERT INTO tblRefund (refundSeq, refundDate, refundRequest, eachOrderSeq, refundCheck) VALUES ('RF'||refund_seq.nextVal, TO_DATE('2022-01-12  23:44:14', 'YYYY-MM-DD hh24:mi:ss'), '제품 상태가 너무 .. ', 'EO47', '회수완료');
INSERT INTO tblRefund (refundSeq, refundDate, refundRequest, eachOrderSeq, refundCheck) VALUES ('RF'||refund_seq.nextVal, TO_DATE('2022-01-12  23:47:21', 'YYYY-MM-DD hh24:mi:ss'), '에휴 다시 재주문할게요 이번 건 취소 부탁드려요', 'EO48', '회수완료');

